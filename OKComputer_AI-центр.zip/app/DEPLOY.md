# AI Call Center — Руководство по деплою

## Быстрый старт (Docker)

```bash
# 1. Клонируйте репозиторий
git clone <repo-url>
cd ai-call-center

# 2. Настройте .env
cp .env.example .env
# Отредактируйте .env — добавьте свои значения

# 3. Соберите и запустите
docker-compose up -d

# 4. Приложение доступно на http://localhost:3000
```

## Деплой на Railway (рекомендуется)

### 1. Подготовка
```bash
# Установите Railway CLI
npm install -g @railway/cli

# Войдите в аккаунт
railway login
```

### 2. Создайте проект
```bash
# Создайте новый проект в Railway Dashboard
# https://railway.app/dashboard

# Привяжите проект
railway link
```

### 3. Добавьте переменные окружения
В Railway Dashboard → Variables:
```
DATABASE_URL=mysql://user:pass@host:3306/db
VITE_KIMI_AUTH_URL=https://auth.example.com
VITE_APP_ID=your-app-id
APP_SECRET=your-secret
VAPI_API_KEY=your-vapi-key
VAPI_WEBHOOK_SECRET=your-webhook-secret
VITE_APP_URL=https://your-app.railway.app
```

### 4. Деплой
```bash
bash deploy-railway.sh
# или
railway up
```

### 5. Настройте домен
В Railway Dashboard → Settings → Domains → Generate Domain

## Деплой на Render

### 1. Создайте Web Service
- Подключите GitHub репозиторий
- Выберите ветку `main`

### 2. Настройки сборки
```
Build Command: npm install && npm run build
Start Command: npm start
```

### 3. Переменные окружения
Добавьте все переменные из `.env` в Environment секцию

### 4. Деплой
Нажмите "Create Web Service" → автоматический деплой

## Деплой на VPS (Ubuntu/Debian)

### 1. Подготовка сервера
```bash
# Обновите систему
sudo apt update && sudo apt upgrade -y

# Установите Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Установите MySQL (или используйте внешнюю БД)
sudo apt install -y mysql-server

# Установите PM2 для управления процессами
sudo npm install -g pm2
```

### 2. Клонируйте и соберите
```bash
git clone <repo-url>
cd ai-call-center
npm install
npm run build
```

### 3. Настройте .env
```bash
nano .env
# Добавьте все переменные
```

### 4. Запуск через PM2
```bash
pm2 start dist/boot.js --name "ai-call-center"
pm2 startup
pm2 save
```

### 5. Настройте Nginx (опционально)
```bash
sudo apt install -y nginx

# Конфиг /etc/nginx/sites-available/ai-call-center
sudo tee /etc/nginx/sites-available/ai-call-center << 'EOF'
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

sudo ln -s /etc/nginx/sites-available/ai-call-center /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Переменные окружения

| Переменная | Описание | Обязательная |
|------------|----------|--------------|
| `DATABASE_URL` | URL MySQL базы данных | ✅ |
| `VITE_KIMI_AUTH_URL` | URL OAuth сервера Kimi | ✅ |
| `VITE_APP_ID` | ID приложения в Kimi | ✅ |
| `APP_SECRET` | Секретный ключ приложения | ✅ |
| `VAPI_API_KEY` | API ключ Vapi.ai | ⚠️ Для звонков |
| `VAPI_WEBHOOK_SECRET` | Секрет webhook Vapi | ⚠️ Для звонков |
| `VITE_APP_URL` | Публичный URL приложения | ⚠️ Для webhooks |

## Проверка работоспособности

```bash
# Проверка API
curl http://localhost:3000/api/trpc/ping

# Ожидаемый ответ: {"result":{"data":{"ok":true,"ts":...}}}
```

## Логи и мониторинг

```bash
# Railway
railway logs

# PM2 на VPS
pm2 logs ai-call-center
pm2 monit

# Docker
docker-compose logs -f
```

## Обновление

```bash
# Получить обновления
git pull

# Пересобрать
npm install
npm run build

# Перезапустить (Docker)
docker-compose up -d --build

# Перезапустить (PM2)
pm2 restart ai-call-center
```

## Поддержка

Проблемы с деплоем? Проверьте:
1. Логи приложения
2. Переменные окружения
3. Доступность базы данных
4. Открытие порта 3000
