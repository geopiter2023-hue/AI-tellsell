import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { clients, type Client } from "@db/schema";
import { eq, desc, like, or } from "drizzle-orm";

export const clientRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(clients).orderBy(desc(clients.createdAt));
  }),

  search: publicQuery
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(clients)
        .where(
          or(
            like(clients.name, `%${input.query}%`),
            like(clients.phone, `%${input.query}%`),
            like(clients.email, `%${input.query}%`),
            like(clients.company, `%${input.query}%`)
          )
        )
        .orderBy(desc(clients.createdAt));
    }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [client] = await db.select().from(clients).where(eq(clients.id, input.id));
      return client || null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string(),
        phone: z.string(),
        email: z.string().optional(),
        company: z.string().optional(),
        notes: z.string().optional(),
        status: z.enum(["lead", "active", "inactive", "blacklisted"]).default("lead"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [client] = await db.insert(clients).values(input);
      return client;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        company: z.string().optional(),
        notes: z.string().optional(),
        status: z.enum(["lead", "active", "inactive", "blacklisted"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(clients).set(data).where(eq(clients.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(clients).where(eq(clients.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allClients: Client[] = await db.select().from(clients);
    return {
      total: allClients.length,
      leads: allClients.filter((c: Client) => c.status === "lead").length,
      active: allClients.filter((c: Client) => c.status === "active").length,
      inactive: allClients.filter((c: Client) => c.status === "inactive").length,
    };
  }),
});
