import { Hono } from "hono";
import { getDb } from "./queries/connection";
import { calls, transcriptEntries } from "@db/schema";
import { eq } from "drizzle-orm";

// Import SSE broadcast function
import { broadcastVapiEvent } from "./sse-router";

export const vapiWebhookRouter = new Hono();

// Vapi sends webhooks to this endpoint
vapiWebhookRouter.post("/vapi", async (c) => {
  try {
    const payload = await c.req.json();
    const eventType = payload.message?.type || payload.type;
    const callId = payload.call?.id;

    console.log("[Vapi Webhook]", eventType, callId);

    const db = getDb();

    switch (eventType) {
      case "call-started": {
        // Find local call by Vapi call ID
        const [localCall] = await db
          .select()
          .from(calls)
          .where(eq(calls.recordingUrl, callId));

        if (localCall) {
          await db
            .update(calls)
            .set({
              status: "in_progress",
              startedAt: new Date(),
            })
            .where(eq(calls.id, localCall.id));

          broadcastVapiEvent({
            type: "call_started",
            callId: localCall.id,
            vapiCallId: callId,
            status: "in_progress",
          });
        }
        break;
      }

      case "call-ended": {
        const [localCall] = await db
          .select()
          .from(calls)
          .where(eq(calls.recordingUrl, callId));

        if (localCall) {
          const duration = payload.call?.duration
            ? Math.round(payload.call.duration)
            : 0;
          const endedReason = payload.call?.endedReason || "completed";

          await db
            .update(calls)
            .set({
              status: "completed",
              duration,
              endedAt: new Date(),
              outcome:
                endedReason === "customer-ended-call"
                  ? "success"
                  : endedReason === "assistant-ended-call"
                    ? "success"
                    : "no_answer",
            })
            .where(eq(calls.id, localCall.id));

          broadcastVapiEvent({
            type: "call_ended",
            callId: localCall.id,
            vapiCallId: callId,
            duration,
            outcome: endedReason,
          });
        }
        break;
      }

      case "transcript": {
        const [localCall] = await db
          .select()
          .from(calls)
          .where(eq(calls.recordingUrl, callId));

        if (localCall) {
          const speaker =
            payload.transcript?.role === "assistant" ? "ai" : "client";
          const text = payload.transcript?.content || "";
          const timestamp = payload.transcript?.startSecond || 0;

          // Detect emotion from text
          const emotion = detectEmotion(text);

          // Save transcript entry
          await db.insert(transcriptEntries).values({
            callId: localCall.id,
            speaker,
            text,
            emotion,
            timestamp: Math.round(timestamp),
          });

          // Update call
          await db
            .update(calls)
            .set({
              transcript: text,
              emotionLabel: emotion,
              duration: Math.round(timestamp),
            })
            .where(eq(calls.id, localCall.id));

          broadcastVapiEvent({
            type: "transcript_line",
            callId: localCall.id,
            speaker,
            text,
            emotion,
            elapsedSeconds: Math.round(timestamp),
          });
        }
        break;
      }

      case "speech-update": {
        // Real-time speech detection
        const [localCall] = await db
          .select()
          .from(calls)
          .where(eq(calls.recordingUrl, callId));

        if (localCall) {
          broadcastVapiEvent({
            type: "speech_update",
            callId: localCall.id,
            status: payload.speechUpdate?.status,
          });
        }
        break;
      }

      case "assistant-message": {
        // Assistant response
        const [localCall] = await db
          .select()
          .from(calls)
          .where(eq(calls.recordingUrl, callId));

        if (localCall) {
          const text = payload.message?.content || "";
          const emotion = detectEmotion(text);

          await db.insert(transcriptEntries).values({
            callId: localCall.id,
            speaker: "ai",
            text,
            emotion,
            timestamp: Math.round(Date.now() / 1000),
          });

          broadcastVapiEvent({
            type: "transcript_line",
            callId: localCall.id,
            speaker: "ai",
            text,
            emotion,
            elapsedSeconds: Math.round(Date.now() / 1000),
          });
        }
        break;
      }

      case "error": {
        const [localCall] = await db
          .select()
          .from(calls)
          .where(eq(calls.recordingUrl, callId));

        if (localCall) {
          await db
            .update(calls)
            .set({ status: "failed" })
            .where(eq(calls.id, localCall.id));

          broadcastVapiEvent({
            type: "call_error",
            callId: localCall.id,
            error: payload.error?.message,
          });
        }
        break;
      }

      default:
        console.log("[Vapi Webhook] Unknown event:", eventType);
    }

    return c.json({ ok: true });
  } catch (error) {
    console.error("[Vapi Webhook Error]", error);
    return c.json({ ok: true }); // Always return 200 to Vapi
  }
});

// Simple emotion detection
function detectEmotion(text: string): string {
  const lower = text.toLowerCase();

  const joyWords = [
    "отлично",
    "здорово",
    "супер",
    "прекрасно",
    "рад",
    "рада",
    "спасибо",
    "благодарю",
    "хорошо",
    "да",
    "конечно",
    "согласен",
    "интересно",
    "любопытно",
    "круто",
    "впечатляет",
  ];
  const angerWords = [
    "нет",
    "не надо",
    "не интересно",
    "не звоните",
    "отстаньте",
    "раздражает",
    "бесит",
    "хватит",
    "не хочу",
    "удалите",
  ];
  const sadWords = [
    "дорого",
    "не знаю",
    "сомневаюсь",
    "может быть",
    "подумаю",
    "позже",
    "не сейчас",
  ];
  const interestWords = [
    "как",
    "расскажите",
    "подробнее",
    "цена",
    "стоимость",
    "возможности",
    "функции",
    "примеры",
  ];

  if (joyWords.some((w) => lower.includes(w))) return "joy";
  if (angerWords.some((w) => lower.includes(w))) return "anger";
  if (interestWords.some((w) => lower.includes(w))) return "interest";
  if (sadWords.some((w) => lower.includes(w))) return "sad";
  return "calm";
}
