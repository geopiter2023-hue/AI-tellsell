import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { secretShopperCalls } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const secretShopperRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(secretShopperCalls).orderBy(desc(secretShopperCalls.createdAt));
  }),

  active: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(secretShopperCalls)
      .where(sql`${secretShopperCalls.status} IN ('calling', 'in_progress')`)
      .orderBy(desc(secretShopperCalls.createdAt));
  }),

  create: publicQuery
    .input(
      z.object({
        shopPhone: z.string(),
        shopName: z.string().optional(),
        shopType: z.enum(["retail", "restaurant", "service", "online", "other"]).default("retail"),
        productName: z.string().optional(),
        scenario: z.enum(["price_inquiry", "product_quality", "purchase_flow", "complaint", "consultation"]).default("price_inquiry"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [call] = await db.insert(secretShopperCalls).values({
        ...input,
        status: "queued",
        duration: 0,
      });
      return call;
    }),

  start: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(secretShopperCalls)
        .set({ status: "calling", startedAt: new Date() })
        .where(eq(secretShopperCalls.id, input.id));
      return { success: true };
    }),

  complete: publicQuery
    .input(
      z.object({
        id: z.number(),
        transcript: z.string().optional(),
        duration: z.number(),
        greeting: z.string().optional(),
        politenessScore: z.number().min(1).max(10).optional(),
        knowledgeScore: z.number().min(1).max(10).optional(),
        helpfulnessScore: z.number().min(1).max(10).optional(),
        clarityScore: z.number().min(1).max(10).optional(),
        overallScore: z.number().min(1).max(10).optional(),
        objections: z.string().optional(),
        recommendations: z.string().optional(),
        followUp: z.string().optional(),
        summary: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db
        .update(secretShopperCalls)
        .set({ ...data, status: "completed", endedAt: new Date() })
        .where(eq(secretShopperCalls.id, id));
      return { success: true };
    }),

  updateTranscript: publicQuery
    .input(z.object({ id: z.number(), transcript: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(secretShopperCalls)
        .set({ transcript: input.transcript })
        .where(eq(secretShopperCalls.id, input.id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(secretShopperCalls).where(eq(secretShopperCalls.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(secretShopperCalls);
    return {
      total: all.length,
      completed: all.filter((c) => c.status === "completed").length,
      avgOverallScore: all.length > 0
        ? Math.round(
            all.filter((c) => c.overallScore).reduce((s, c) => s + (c.overallScore || 0), 0) /
              all.filter((c) => c.overallScore).length
          )
        : 0,
      avgPoliteness: all.length > 0
        ? Math.round(
            all.filter((c) => c.politenessScore).reduce((s, c) => s + (c.politenessScore || 0), 0) /
              all.filter((c) => c.politenessScore).length
          )
        : 0,
      avgKnowledge: all.length > 0
        ? Math.round(
            all.filter((c) => c.knowledgeScore).reduce((s, c) => s + (c.knowledgeScore || 0), 0) /
              all.filter((c) => c.knowledgeScore).length
          )
        : 0,
    };
  }),
});
