import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { calls, transcriptEntries, type Call } from "@db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const callRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(calls).orderBy(desc(calls.createdAt));
  }),

  active: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(calls)
      .where(
        sql`${calls.status} IN ('ringing', 'in_progress', 'queued')`
      )
      .orderBy(desc(calls.createdAt));
  }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [call] = await db.select().from(calls).where(eq(calls.id, input.id));
      return call || null;
    }),

  transcript: publicQuery
    .input(z.object({ callId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(transcriptEntries)
        .where(eq(transcriptEntries.callId, input.callId))
        .orderBy(transcriptEntries.timestamp);
    }),

  create: publicQuery
    .input(
      z.object({
        campaignId: z.number().optional(),
        clientId: z.number().optional(),
        agentId: z.number().optional(),
        direction: z.enum(["inbound", "outbound"]),
        phone: z.string(),
        clientName: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [call] = await db.insert(calls).values({
        ...input,
        status: "queued",
        outcome: "in_progress",
      });
      return call;
    }),

  updateStatus: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["queued", "ringing", "in_progress", "completed", "failed", "missed"]),
        duration: z.number().optional(),
        emotionScore: z.number().optional(),
        emotionLabel: z.string().optional(),
        transcript: z.string().optional(),
        outcome: z.enum(["success", "follow_up", "no_answer", "rejected", "voicemail", "in_progress"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(calls).set(data).where(eq(calls.id, id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allCalls: Call[] = await db.select().from(calls);
    const active = allCalls.filter((c: Call) => ["ringing", "in_progress"].includes(c.status)).length;
    const queued = allCalls.filter((c: Call) => c.status === "queued").length;
    const completed = allCalls.filter((c: Call) => c.status === "completed").length;
    const totalDuration = allCalls.reduce((sum: number, c: Call) => sum + c.duration, 0);
    const avgEmotion = allCalls.length > 0
      ? Math.round(allCalls.reduce((sum: number, c: Call) => sum + c.emotionScore, 0) / allCalls.length)
      : 50;

    return {
      active,
      queued,
      completed: completed + allCalls.filter((c: Call) => c.status === "failed" || c.status === "missed").length,
      totalCalls: allCalls.length,
      totalDuration,
      avgEmotion,
      successRate: allCalls.length > 0
        ? Math.round((allCalls.filter((c: Call) => c.outcome === "success").length / allCalls.length) * 100)
        : 0,
    };
  }),

  addTranscriptEntry: publicQuery
    .input(
      z.object({
        callId: z.number(),
        speaker: z.enum(["ai", "client"]),
        text: z.string(),
        emotion: z.string().optional(),
        timestamp: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(transcriptEntries).values(input);
      return { success: true };
    }),

  endCall: publicQuery
    .input(
      z.object({
        id: z.number(),
        duration: z.number(),
        outcome: z.enum(["success", "follow_up", "no_answer", "rejected", "voicemail", "in_progress"]),
        emotionScore: z.number(),
        emotionLabel: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db
        .update(calls)
        .set({
          ...data,
          status: "completed",
          endedAt: new Date(),
        })
        .where(eq(calls.id, id));
      return { success: true };
    }),
});
