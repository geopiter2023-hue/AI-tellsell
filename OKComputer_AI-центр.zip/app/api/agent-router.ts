import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { agents, type Agent } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const agentRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(agents).orderBy(desc(agents.createdAt));
  }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [agent] = await db.select().from(agents).where(eq(agents.id, input.id));
      return agent || null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string(),
        voice: z.string().default("female-warm"),
        language: z.string().default("ru-RU"),
        emotionProfile: z.enum(["professional", "friendly", "calm", "energetic"]).default("friendly"),
        greetingScript: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [agent] = await db.insert(agents).values({
        ...input,
        status: "active",
        callsHandled: 0,
        successRate: 0,
      });
      return agent;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        voice: z.string().optional(),
        language: z.string().optional(),
        emotionProfile: z.enum(["professional", "friendly", "calm", "energetic"]).optional(),
        greetingScript: z.string().optional(),
        status: z.enum(["active", "paused", "offline"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(agents).set(data).where(eq(agents.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(agents).where(eq(agents.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allAgents: Agent[] = await db.select().from(agents);
    return {
      total: allAgents.length,
      active: allAgents.filter((a: Agent) => a.status === "active").length,
      paused: allAgents.filter((a: Agent) => a.status === "paused").length,
      totalCalls: allAgents.reduce((sum: number, a: Agent) => sum + a.callsHandled, 0),
      avgSuccessRate: allAgents.length > 0
        ? Math.round(allAgents.reduce((sum: number, a: Agent) => sum + a.successRate, 0) / allAgents.length)
        : 0,
    };
  }),
});
