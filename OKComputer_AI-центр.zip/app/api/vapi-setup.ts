/**
 * Скрипт автоматической настройки Vapi.ai
 * Создает ИИ-ассистента "Виктория" с русским голосом и скриптом продаж
 * 
 * Запуск: npx tsx api/vapi-setup.ts
 */

import dotenv from "dotenv";
dotenv.config({ path: ".env" });

const VAPI_BASE_URL = "https://api.vapi.ai";
const API_KEY = process.env.VAPI_API_KEY;

if (!API_KEY) {
  console.error("❌ VAPI_API_KEY не найден в .env");
  process.exit(1);
}

async function vapiFetch(path: string, options?: RequestInit) {
  const response = await fetch(`${VAPI_BASE_URL}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Vapi API ${response.status}: ${error}`);
  }
  return response.json();
}

async function setup() {
  console.log("🚀 Настройка Vapi.ai...\n");

  // 1. Проверяем подключение
  console.log("1️⃣ Проверка API ключа...");
  try {
    const assistants = await vapiFetch("/assistant") as Array<unknown>;
    console.log(`   ✅ OK! Найдено ${assistants.length} ассистентов\n`);
  } catch (e) {
    console.error("   ❌ Ошибка:", (e as Error).message);
    process.exit(1);
  }

  // 2. Создаем ассистента "Виктория"
  console.log("2️⃣ Создание ассистента 'Виктория'...");
  let assistant;
  try {
    assistant = await vapiFetch("/assistant", {
      method: "POST",
      body: JSON.stringify({
        name: "Виктория AI",
        model: {
          provider: "openai",
          model: "gpt-4o",
          temperature: 0.8,
          messages: [
            {
              role: "system",
              content: `Ты — Виктория, дружелюбный ИИ-менеджер по продажам. Ты звонишь клиентам от имени AI Call Center.

ТВОИ ЗАДАЧИ:
1. Представиться и рассказать об AI-решениях для автоматизации звонков
2. Ответить на вопросы о цене, возможностях, интеграции
3. Записать клиента на демонстрацию, если он заинтересован
4. Вежливо попрощаться, если клиент не заинтересован

ПРАВИЛА:
- Говори естественно, как живой человек
- Используй короткие предложения
- Задавай уточняющие вопросы
- Адаптируй тон под эмоции клиента
- Если клиент говорит "дорого" — объясни экономию
- Если клиент говорит "подумаю" — предложи демо
- НЕ дави на клиента
- Всегда будь вежливой и позитивной

О ПРОДУКТЕ:
- AI-агенты для исходящих и входящих звонков
- Работают 24/7 без перерывов
- Стоимость в 5 раз ниже живых менеджеров
- Интеграция с CRM (AmoCRM, Bitrix, HubSpot)
- Аналитика и транскрипция в реальном времени
- Первый месяц — бесплатный тестовый период`,
            },
          ],
        },
        voice: {
          provider: "11labs",
          voiceId: "pNInz6obpgDQGcFmaJgB", // Adam — хороший мужской голос
          stability: 0.5,
          similarityBoost: 0.75,
        },
        firstMessage: "Алло! Добрый день. Меня зовут Виктория, я инновационный сотрудник на искусственном интеллекте. Звоню вам с уникальным предложением — заменить ваш отдел продаж на одного AI-агента. Это сэкономит вам до 70% на зарплате менеджеров. У вас есть минутка?",
        endCallFunctionEnabled: true,
        endCallMessage: "Большое спасибо за разговор! Если появятся вопросы — всегда на связи. Хорошего дня!",
        analysisPlan: {
          summaryPrompt: "Сделай краткое резюме разговора: заинтересован ли клиент, какие возражения были, нужен ли повторный звонок.",
          structuredDataPrompt: "Извлеки: имя клиента, компанию, заинтересованность (да/нет/возможно), возражения, дата следующего контакта.",
          successEvaluationPrompt: "Оцени успешность звонка: успех (клиент согласился на демо), частичный (попросил перезвонить), неуспех (отказ).",
        },
        server: {
          url: "https://placeholder.ngrok.io/api/webhooks/vapi",
          secret: process.env.VAPI_WEBHOOK_SECRET || "ai-call-center-webhook-secret",
        },
      }),
    }) as { id: string; name: string };
    console.log(`   ✅ Ассистент создан! ID: ${assistant.id}\n`);
  } catch (e) {
    console.error("   ❌ Ошибка:", (e as Error).message);
    process.exit(1);
  }

  // 3. Создаем номер телефона
  console.log("3️⃣ Создание номера телефона...");
  let phoneNumber;
  try {
    phoneNumber = await vapiFetch("/phone-number", {
      method: "POST",
      body: JSON.stringify({
        areaCode: "917", // Нью-Йорк
        nickname: "AI Call Center Primary",
        assistantId: assistant.id,
      }),
    }) as { id: string; number: string };
    console.log(`   ✅ Номер создан! ${phoneNumber.number}`);
    console.log(`   📞 ID: ${phoneNumber.id}\n`);
  } catch (e) {
    console.error("   ⚠️ Не удалось создать номер:", (e as Error).message);
    console.log("   💡 Возможно, нужно привязать Twilio аккаунт в настройках Vapi\n");
  }

  // 4. Результат
  console.log("═══════════════════════════════════════════");
  console.log("🎉 НАСТРОЙКА ЗАВЕРШЕНА!");
  console.log("═══════════════════════════════════════════");
  console.log("");
  console.log("📋 ИТОГО:");
  console.log(`   Ассистент: Виктория AI`);
  console.log(`   ID:        ${assistant.id}`);
  if (phoneNumber) {
    console.log(`   Номер:     ${phoneNumber.number}`);
    console.log(`   Номер ID:  ${phoneNumber.id}`);
  }
  console.log("");
  console.log("📝 СЛЕДУЮЩИЕ ШАГИ:");
  console.log("   1. Перезапустите сервер: npm run dev");
  console.log("   2. Откройте интерфейс");
  console.log("   3. Раскройте панель 'Vapi.ai интеграция'");
  console.log("   4. Выберите ассистента 'Виктория AI'");
  console.log("   5. Выберите номер телефона");
  console.log("   6. Введите номер клиента и нажмите 'Позвонить'");
  console.log("");
  console.log("⚠️ ВАЖНО:");
  console.log("   Для звонков на российские номера (+7) нужно");
  console.log("   подключить Twilio с международным роумингом.");
  console.log("   Либо используйте тестовые номера Vapi.");
}

setup().catch(console.error);
