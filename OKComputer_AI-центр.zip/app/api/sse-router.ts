import { Hono } from "hono";
import { getDb } from "./queries/connection";
import { calls, transcriptEntries } from "@db/schema";
import { eq } from "drizzle-orm";

// Global call simulator state
let simulatorInterval: ReturnType<typeof setInterval> | null = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let clients: { id: number; controller: any }[] = [];
let nextClientId = 1;

// Russian conversation scripts for simulation
const conversationScripts = [
  {
    lines: [
      { speaker: "ai" as const, text: "Алло! Добрый день. Меня зовут Виктория, я инновационный сотрудник на искусственном интеллекте.", emotion: "joy" },
      { speaker: "client" as const, text: "Здравствуйте. Ого, вы правда ИИ? Звучите очень естественно!", emotion: "joy" },
      { speaker: "ai" as const, text: "Да, именно так! И я звоню, чтобы предложить вам заменить отдел продаж на одного ИИ-агента. Экономия до 70%!", emotion: "joy" },
      { speaker: "client" as const, text: "Интересно... А как насчёт сложных переговоров?", emotion: "calm" },
      { speaker: "ai" as const, text: "Я могу адаптировать эмоциональную окраску в реальном времени, обрабатывать возражения и даже шутить!", emotion: "joy" },
      { speaker: "client" as const, text: "Хорошо, давайте назначим демонстрацию на завтра.", emotion: "joy" },
    ],
    clientName: "Алексей Морозов",
    phone: "+7 (999) 111-22-33",
  },
  {
    lines: [
      { speaker: "ai" as const, text: "Добрый день! Меня зовут Максим, ваш ИИ-ассистент. Как дела?", emotion: "calm" },
      { speaker: "client" as const, text: "Здравствуйте. Я сейчас занят, у вас есть 2 минуты?", emotion: "calm" },
      { speaker: "ai" as const, text: "Конечно! Я работаю 24/7 без перерывов. Могу перезвонить в любое удобное время.", emotion: "joy" },
      { speaker: "client" as const, text: "Отлично. Расскажите кратко, что вы предлагаете.", emotion: "interest" },
      { speaker: "ai" as const, text: "Автоматизация звонков с анализом эмоций. Я звоню клиентам, записываю на встречи и веду отчёты.", emotion: "joy" },
      { speaker: "client" as const, text: "Звучит круто. Давайте созвонимся подробнее в четверг.", emotion: "joy" },
    ],
    clientName: "Екатерина Волкова",
    phone: "+7 (999) 222-33-44",
  },
  {
    lines: [
      { speaker: "ai" as const, text: "Здравствуйте! Виктория на связи. Звоню по поводу наших ИИ-решений для бизнеса.", emotion: "joy" },
      { speaker: "client" as const, text: "Мы уже используем роботов, не интересует.", emotion: "anger" },
      { speaker: "ai" as const, text: "Понимаю! Но наши агенты понимают контекст и эмоции — это не просто роботы. Могу показать разницу за 5 минут.", emotion: "calm" },
      { speaker: "client" as const, text: "Ну... ладно, 5 минут. Чем вы отличаетесь?", emotion: "calm" },
      { speaker: "ai" as const, text: "Я чувствую настроение собеседника и подстраиваюсь. Если клиент злится — успокаиваю. Если рад — поддерживаю энергию!", emotion: "joy" },
      { speaker: "client" as const, text: "Впечатляет. Давайте попробуем тестовый период.", emotion: "joy" },
    ],
    clientName: "Сергей Николаев",
    phone: "+7 (999) 333-44-55",
  },
  {
    lines: [
      { speaker: "ai" as const, text: "Добрый день! Меня зовут Елена. Я звоню, чтобы рассказать о сервисе автоматизации звонков.", emotion: "calm" },
      { speaker: "client" as const, text: "Ага, слушаю.", emotion: "neutral" },
      { speaker: "ai" as const, text: "Наш ИИ обрабатывает входящие и исходящие звонки, записывает клиентов и ведёт аналитику. Всё автоматически!", emotion: "joy" },
      { speaker: "client" as const, text: "А сколько это стоит по сравнению с живыми менеджерами?", emotion: "interest" },
      { speaker: "ai" as const, text: "В 5 раз дешевле одного менеджера, а работает как 10! Плюс не уходит в отпуск и не болеет.", emotion: "joy" },
      { speaker: "client" as const, text: "Серьёзно? Давайте созвонимся с моим руководителем.", emotion: "joy" },
    ],
    clientName: "Ольга Петрова",
    phone: "+7 (999) 444-55-66",
  },
];

// In-memory active call simulations
const activeSimulations: Map<number, {
  callId: number;
  scriptIndex: number;
  lineIndex: number;
  clientName: string;
  phone: string;
  lines: Array<{ speaker: "ai" | "client"; text: string; emotion: string }>;
}> = new Map();

export function broadcastVapiEvent(data: unknown) {
  broadcast(data);
}

function broadcast(data: unknown) {
  const message = `data: ${JSON.stringify(data)}\n\n`;
  const encoder = new TextEncoder();
  const bytes = encoder.encode(message);
  clients.forEach((c) => {
    try {
      c.controller.enqueue(bytes);
    } catch {
      // Client disconnected
    }
  });
}

async function startNewCallSimulation() {
  const db = getDb();
  const script = conversationScripts[Math.floor(Math.random() * conversationScripts.length)];
  
  // Create a new call
  const [result] = await db.insert(calls).values({
    campaignId: 1,
    agentId: 1,
    direction: "outbound",
    status: "ringing",
    phone: script.phone,
    clientName: script.clientName,
    duration: 0,
    emotionScore: 50,
    emotionLabel: "neutral",
    transcript: "",
    outcome: "in_progress",
    startedAt: new Date(),
  });

  const callId = Number(result.insertId);

  activeSimulations.set(callId, {
    callId,
    scriptIndex: 0,
    lineIndex: 0,
    clientName: script.clientName,
    phone: script.phone,
    lines: script.lines,
  });

  // Start ringing
  broadcast({
    type: "call_started",
    call: {
      id: callId,
      clientName: script.clientName,
      phone: script.phone,
      status: "ringing",
      duration: 0,
      emotionLabel: "neutral",
      direction: "outbound",
    },
  });

  // After 3 seconds, connect the call
  setTimeout(async () => {
    await db.update(calls).set({ status: "in_progress" }).where(eq(calls.id, callId));
    
    broadcast({
      type: "call_connected",
      callId,
    });

    // Start sending transcript lines
    startTranscriptSimulation(callId);
  }, 3000);
}

async function startTranscriptSimulation(callId: number) {
  const sim = activeSimulations.get(callId);
  if (!sim) return;

  const db = getDb();
  let elapsedSeconds = 0;

  for (const line of sim.lines) {
    // Wait 4-8 seconds between lines
    const delay = 4000 + Math.random() * 4000;
    await new Promise((r) => setTimeout(r, delay));
    elapsedSeconds += Math.round(delay / 1000);

    // Insert transcript entry
    await db.insert(transcriptEntries).values({
      callId,
      speaker: line.speaker,
      text: line.text,
      emotion: line.emotion,
      timestamp: elapsedSeconds,
    });

    // Update call
    await db.update(calls)
      .set({
        duration: elapsedSeconds,
        emotionLabel: line.emotion,
        transcript: `${line.speaker === "ai" ? "ИИ" : "Клиент"}: ${line.text}`,
      })
      .where(eq(calls.id, callId));

    broadcast({
      type: "transcript_line",
      callId,
      speaker: line.speaker,
      text: line.text,
      emotion: line.emotion,
      elapsedSeconds,
    });
  }

  // Complete the call
  await new Promise((r) => setTimeout(r, 2000));
  elapsedSeconds += 2;

  await db.update(calls)
    .set({
      status: "completed",
      duration: elapsedSeconds,
      outcome: Math.random() > 0.3 ? "success" : "follow_up",
      emotionLabel: "joy",
      endedAt: new Date(),
    })
    .where(eq(calls.id, callId));

  broadcast({
    type: "call_completed",
    callId,
    duration: elapsedSeconds,
    outcome: Math.random() > 0.3 ? "success" : "follow_up",
  });

  activeSimulations.delete(callId);
}

export function startSimulator() {
  if (simulatorInterval) return; // Already running

  // Start first call immediately
  startNewCallSimulation();

  // Start a new call every 20-40 seconds
  simulatorInterval = setInterval(() => {
    if (activeSimulations.size < 3) {
      startNewCallSimulation();
    }
  }, 20000 + Math.random() * 20000);
}

export function stopSimulator() {
  if (simulatorInterval) {
    clearInterval(simulatorInterval);
    simulatorInterval = null;
  }
}

export const sseRouter = new Hono();

sseRouter.get("/calls", (c) => {
  const stream = new ReadableStream({
    start(controller) {
      const clientId = nextClientId++;
      clients.push({ id: clientId, controller });

      // Send initial connection message
      const encoder = new TextEncoder();
      controller.enqueue(encoder.encode("data: {\"type\":\"connected\"}\n\n"));

      // Start simulator if not running
      startSimulator();

      // Cleanup on client disconnect
      c.req.raw.signal.addEventListener("abort", () => {
        clients = clients.filter((c) => c.id !== clientId);
        if (clients.length === 0) {
          stopSimulator();
        }
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
});
