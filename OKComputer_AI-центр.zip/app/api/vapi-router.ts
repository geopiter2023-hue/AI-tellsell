import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { calls, agents } from "@db/schema";
import { eq } from "drizzle-orm";

// Vapi API configuration
const VAPI_BASE_URL = "https://api.vapi.ai";

// Helper to make Vapi API calls
async function vapiFetch(path: string, apiKey: string, options?: RequestInit) {
  const response = await fetch(`${VAPI_BASE_URL}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Vapi API error: ${response.status} - ${error}`);
  }
  return response.json();
}

export const vapiRouter = createRouter({
  // Check if API key is configured
  status: publicQuery.query(async () => {
    const apiKey = process.env.VAPI_API_KEY;
    if (!apiKey) {
      return { configured: false, message: "API ключ не настроен" };
    }
    try {
      const assistants = await vapiFetch("/assistant", apiKey) as Array<unknown>;
      return { configured: true, assistantsCount: assistants?.length || 0 };
    } catch {
      return { configured: false, message: "Неверный API ключ" };
    }
  }),

  // List assistants from Vapi
  listAssistants: publicQuery.query(async () => {
    const apiKey = process.env.VAPI_API_KEY;
    if (!apiKey) return [];
    try {
      return await vapiFetch("/assistant", apiKey);
    } catch {
      return [];
    }
  }),

  // Create a new assistant
  createAssistant: publicQuery
    .input(
      z.object({
        name: z.string(),
        systemPrompt: z.string(),
        firstMessage: z.string(),
        voiceProvider: z.string().default("11labs"),
        voiceId: z.string().default("pNInz6obpgDQGcFmaJgB"),
        modelProvider: z.string().default("openai"),
        model: z.string().default("gpt-4o"),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = process.env.VAPI_API_KEY;
      if (!apiKey) throw new Error("Vapi API ключ не настроен");

      const assistant = await vapiFetch("/assistant", apiKey, {
        method: "POST",
        body: JSON.stringify({
          name: input.name,
          model: {
            provider: input.modelProvider,
            model: input.model,
            messages: [
              {
                role: "system",
                content: input.systemPrompt,
              },
            ],
          },
          voice: {
            provider: input.voiceProvider,
            voiceId: input.voiceId,
          },
          firstMessage: input.firstMessage,
        }),
      });

      // Also save to local DB
      const db = getDb();
      await db.insert(agents).values({
        name: input.name,
        voice: `${input.voiceProvider}-${input.voiceId}`,
        language: "ru-RU",
        emotionProfile: "friendly",
        greetingScript: input.firstMessage,
        status: "active",
        callsHandled: 0,
        successRate: 0,
      });

      return assistant;
    }),

  // Get phone numbers
  listPhoneNumbers: publicQuery.query(async () => {
    const apiKey = process.env.VAPI_API_KEY;
    if (!apiKey) return [];
    try {
      return await vapiFetch("/phone-number", apiKey);
    } catch {
      return [];
    }
  }),

  // Create a phone number
  createPhoneNumber: publicQuery
    .input(z.object({ areaCode: z.string().optional() }))
    .mutation(async ({ input }) => {
      const apiKey = process.env.VAPI_API_KEY;
      if (!apiKey) throw new Error("Vapi API ключ не настроен");
      return vapiFetch("/phone-number", apiKey, {
        method: "POST",
        body: JSON.stringify({
          areaCode: input.areaCode || "917",
        }),
      });
    }),

  // Make an outbound call
  makeCall: publicQuery
    .input(
      z.object({
        assistantId: z.string(),
        phoneNumberId: z.string(),
        customerNumber: z.string(),
        customerName: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = process.env.VAPI_API_KEY;
      if (!apiKey) throw new Error("Vapi API ключ не настроен");

      const db = getDb();

      // Create call record in DB
      const [result] = await db.insert(calls).values({
        agentId: 1,
        direction: "outbound",
        status: "ringing",
        phone: input.customerNumber,
        clientName: input.customerName || input.customerNumber,
        duration: 0,
        emotionScore: 50,
        emotionLabel: "neutral",
        transcript: "",
        outcome: "in_progress",
        startedAt: new Date(),
      });

      const callId = Number(result.insertId);

      // Make the actual Vapi call
      const vapiCall = await vapiFetch("/call", apiKey, {
        method: "POST",
        body: JSON.stringify({
          assistantId: input.assistantId,
          phoneNumberId: input.phoneNumberId,
          customer: {
            number: input.customerNumber,
            name: input.customerName,
          },
        }),
      }) as { id: string };

      // Update call with Vapi call ID
      await db
        .update(calls)
        .set({ recordingUrl: vapiCall.id })
        .where(eq(calls.id, callId));

      return { localCallId: callId, vapiCallId: vapiCall.id };
    }),

  // Import phone number from Twilio
  importPhoneNumber: publicQuery
    .input(
      z.object({
        twilioAccountSid: z.string(),
        twilioAuthToken: z.string(),
        twilioPhoneNumber: z.string(),
        assistantId: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = process.env.VAPI_API_KEY;
      if (!apiKey) throw new Error("Vapi API ключ не настроен");

      return vapiFetch("/phone-number/import", apiKey, {
        method: "POST",
        body: JSON.stringify({
          provider: "twilio",
          authAccountSid: input.twilioAccountSid,
          authToken: input.twilioAuthToken,
          number: input.twilioPhoneNumber,
          assistantId: input.assistantId,
        }),
      });
    }),

  // Set webhook URL for a phone number
  setWebhook: publicQuery
    .input(
      z.object({
        phoneNumberId: z.string(),
        webhookUrl: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = process.env.VAPI_API_KEY;
      if (!apiKey) throw new Error("Vapi API ключ не настроен");

      return vapiFetch(`/phone-number/${input.phoneNumberId}`, apiKey, {
        method: "PATCH",
        body: JSON.stringify({
          serverUrl: input.webhookUrl,
          serverUrlSecret: process.env.VAPI_WEBHOOK_SECRET || "",
        }),
      });
    }),

  // Get call details from Vapi
  getCallDetails: publicQuery
    .input(z.object({ vapiCallId: z.string() }))
    .query(async ({ input }) => {
      const apiKey = process.env.VAPI_API_KEY;
      if (!apiKey) return null;
      try {
        return await vapiFetch(`/call/${input.vapiCallId}`, apiKey);
      } catch {
        return null;
      }
    }),

  // List recent calls from Vapi
  listVapiCalls: publicQuery.query(async () => {
    const apiKey = process.env.VAPI_API_KEY;
    if (!apiKey) return [];
    try {
      return await vapiFetch("/call", apiKey);
    } catch {
      return [];
    }
  }),
});
