import { authRouter } from "./auth-router";
import { callRouter } from "./call-router";
import { clientRouter } from "./client-router";
import { campaignRouter } from "./campaign-router";
import { agentRouter } from "./agent-router";
import { analyticsRouter } from "./analytics-router";
import { vapiRouter } from "./vapi-router";
import { secretShopperRouter } from "./secret-shopper-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  calls: callRouter,
  clients: clientRouter,
  campaigns: campaignRouter,
  agents: agentRouter,
  analytics: analyticsRouter,
  vapi: vapiRouter,
  secretShopper: secretShopperRouter,
});

export type AppRouter = typeof appRouter;
