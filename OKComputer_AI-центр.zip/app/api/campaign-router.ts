import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { campaigns, type Campaign } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const campaignRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(campaigns).orderBy(desc(campaigns.createdAt));
  }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, input.id));
      return campaign || null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string(),
        description: z.string().optional(),
        type: z.enum(["outbound", "inbound"]),
        agentId: z.number().optional(),
        script: z.string().optional(),
        targetCount: z.number().default(0),
        scheduledAt: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [campaign] = await db.insert(campaigns).values({
        ...input,
        status: "draft",
        callsMade: 0,
        callsAnswered: 0,
        successRate: 0,
        scheduledAt: input.scheduledAt ? new Date(input.scheduledAt) : null,
      });
      return campaign;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["draft", "running", "paused", "completed"]).optional(),
        agentId: z.number().optional(),
        script: z.string().optional(),
        targetCount: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(campaigns).set(data).where(eq(campaigns.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(campaigns).where(eq(campaigns.id, input.id));
      return { success: true };
    }),

  toggleStatus: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, input.id));
      if (!campaign) return { success: false };

      const newStatus = campaign.status === "running" ? "paused" : "running";
      await db.update(campaigns).set({ status: newStatus }).where(eq(campaigns.id, input.id));
      return { success: true, status: newStatus };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const allCampaigns: Campaign[] = await db.select().from(campaigns);
    return {
      total: allCampaigns.length,
      running: allCampaigns.filter((c: Campaign) => c.status === "running").length,
      paused: allCampaigns.filter((c: Campaign) => c.status === "paused").length,
      completed: allCampaigns.filter((c: Campaign) => c.status === "completed").length,
      draft: allCampaigns.filter((c: Campaign) => c.status === "draft").length,
      totalCallsMade: allCampaigns.reduce((sum: number, c: Campaign) => sum + c.callsMade, 0),
      avgSuccessRate: allCampaigns.length > 0
        ? Math.round(allCampaigns.reduce((sum: number, c: Campaign) => sum + c.successRate, 0) / allCampaigns.length)
        : 0,
    };
  }),
});
