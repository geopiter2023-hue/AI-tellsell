import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { calls, campaigns, clients, agents, type Call } from "@db/schema";

export const analyticsRouter = createRouter({
  dashboard: publicQuery.query(async () => {
    const db = getDb();
    const allCalls: Call[] = await db.select().from(calls);
    const allCampaigns = await db.select().from(campaigns);
    const allClients = await db.select().from(clients);

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const todayCalls = allCalls.filter((c: Call) => c.createdAt && c.createdAt >= todayStart);
    const weekCalls = allCalls.filter((c: Call) => c.createdAt && c.createdAt >= weekAgo);

    // Hourly distribution
    const hourlyStats = Array.from({ length: 24 }, (_, i) => {
      const hourCalls = allCalls.filter((c: Call) => {
        if (!c.startedAt) return false;
        return c.startedAt.getHours() === i;
      });
      return {
        hour: i,
        calls: hourCalls.length,
        avgDuration: hourCalls.length > 0
          ? Math.round(hourCalls.reduce((s: number, c: Call) => s + c.duration, 0) / hourCalls.length)
          : 0,
      };
    });

    // Emotion distribution
    const emotionStats = {
      joy: allCalls.filter((c: Call) => c.emotionLabel === "joy").length,
      calm: allCalls.filter((c: Call) => c.emotionLabel === "calm").length,
      anger: allCalls.filter((c: Call) => c.emotionLabel === "anger").length,
      sad: allCalls.filter((c: Call) => c.emotionLabel === "sad").length,
      neutral: allCalls.filter((c: Call) => !c.emotionLabel || c.emotionLabel === "neutral").length,
    };

    // Outcome distribution
    const outcomeStats = {
      success: allCalls.filter((c: Call) => c.outcome === "success").length,
      follow_up: allCalls.filter((c: Call) => c.outcome === "follow_up").length,
      no_answer: allCalls.filter((c: Call) => c.outcome === "no_answer").length,
      rejected: allCalls.filter((c: Call) => c.outcome === "rejected").length,
      voicemail: allCalls.filter((c: Call) => c.outcome === "voicemail").length,
      in_progress: allCalls.filter((c: Call) => c.outcome === "in_progress").length,
    };

    return {
      summary: {
        totalCalls: allCalls.length,
        activeCalls: allCalls.filter((c: Call) => ["ringing", "in_progress"].includes(c.status)).length,
        totalClients: allClients.length,
        totalCampaigns: allCampaigns.length,
        runningCampaigns: allCampaigns.filter((c) => c.status === "running").length,
        todayCalls: todayCalls.length,
        weekCalls: weekCalls.length,
        avgCallDuration: allCalls.length > 0
          ? Math.round(allCalls.reduce((s: number, c: Call) => s + c.duration, 0) / allCalls.length)
          : 0,
        overallSuccessRate: allCalls.length > 0
          ? Math.round((allCalls.filter((c: Call) => c.outcome === "success").length / allCalls.length) * 100)
          : 0,
      },
      hourlyStats,
      emotionStats,
      outcomeStats,
      campaigns: allCampaigns.map(c => ({
        id: c.id,
        name: c.name,
        callsMade: c.callsMade,
        successRate: c.successRate,
        status: c.status,
      })),
    };
  }),

  callsOverTime: publicQuery
    .input(
      z.object({
        days: z.number().default(7),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const allCalls: Call[] = await db.select().from(calls);
      const now = new Date();

      const result = Array.from({ length: input.days }, (_, i) => {
        const date = new Date(now.getTime() - (input.days - 1 - i) * 24 * 60 * 60 * 1000);
        const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        const dayEnd = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);

        const dayCalls = allCalls.filter((c: Call) => {
          if (!c.createdAt) return false;
          return c.createdAt >= dayStart && c.createdAt < dayEnd;
        });

        return {
          date: date.toISOString().split("T")[0],
          total: dayCalls.length,
          completed: dayCalls.filter((c: Call) => c.status === "completed").length,
          failed: dayCalls.filter((c: Call) => c.status === "failed" || c.status === "missed").length,
        };
      });

      return result;
    }),

  topPerformers: publicQuery.query(async () => {
    const db = getDb();
    const allAgents = await db.select().from(agents);
    return allAgents
      .sort((a, b) => b.successRate - a.successRate)
      .slice(0, 5)
      .map(a => ({
        id: a.id,
        name: a.name,
        callsHandled: a.callsHandled,
        successRate: a.successRate,
        status: a.status,
      }));
  }),
});
