#!/bin/bash
# AI Call Center — Deploy to Railway
# Prerequisites: npm install -g @railway/cli
#                railway login

set -e

echo "🚀 Деплой AI Call Center на Railway..."

# Check if railway CLI is installed
if ! command -v railway &> /dev/null; then
    echo "❌ Railway CLI не установлен. Установите: npm install -g @railway/cli"
    exit 1
fi

# Check if logged in
if ! railway whoami &> /dev/null; then
    echo "❌ Не выполнен вход в Railway. Запустите: railway login"
    exit 1
fi

echo "📦 Сборка проекта..."
npm run build

echo "🔗 Привязка к проекту Railway..."
railway link

echo "🔧 Настройка переменных окружения..."
echo "Добавьте переменные окружения в Railway Dashboard:"
echo "  - DATABASE_URL"
echo "  - VITE_KIMI_AUTH_URL"
echo "  - VITE_APP_ID"
echo "  - APP_SECRET"
echo "  - VAPI_API_KEY"
echo "  - VAPI_WEBHOOK_SECRET"
echo "  - VITE_APP_URL (URL вашего приложения на Railway)"

echo "🚀 Деплой..."
railway up

echo "✅ Деплой завершён!"
echo "Проверьте логи: railway logs"
echo "Откройте приложение: railway open"
