import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// AI Agents — голосовые агенты
export const agents = mysqlTable("agents", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  voice: varchar("voice", { length: 100 }).notNull().default("female-warm"),
  language: varchar("language", { length: 50 }).notNull().default("ru-RU"),
  emotionProfile: mysqlEnum("emotionProfile", ["professional", "friendly", "calm", "energetic"]).default("friendly").notNull(),
  greetingScript: text("greetingScript"),
  status: mysqlEnum("status", ["active", "paused", "offline"]).default("active").notNull(),
  callsHandled: int("callsHandled").default(0).notNull(),
  successRate: int("successRate").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = typeof agents.$inferInsert;

// Clients — клиентская база
export const clients = mysqlTable("clients", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  email: varchar("email", { length: 320 }),
  company: varchar("company", { length: 255 }),
  status: mysqlEnum("status", ["lead", "active", "inactive", "blacklisted"]).default("lead").notNull(),
  notes: text("notes"),
  lastCallAt: timestamp("lastCallAt"),
  totalCalls: int("totalCalls").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Client = typeof clients.$inferSelect;
export type InsertClient = typeof clients.$inferInsert;

// Campaigns — кампании обзвона
export const campaigns = mysqlTable("campaigns", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["outbound", "inbound"]).notNull(),
  status: mysqlEnum("status", ["draft", "running", "paused", "completed"]).default("draft").notNull(),
  agentId: bigint("agentId", { mode: "number", unsigned: true }),
  script: text("script"),
  targetCount: int("targetCount").default(0).notNull(),
  callsMade: int("callsMade").default(0).notNull(),
  callsAnswered: int("callsAnswered").default(0).notNull(),
  successRate: int("successRate").default(0).notNull(),
  scheduledAt: timestamp("scheduledAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

// Calls — звонки
export const calls = mysqlTable("calls", {
  id: serial("id").primaryKey(),
  campaignId: bigint("campaignId", { mode: "number", unsigned: true }),
  clientId: bigint("clientId", { mode: "number", unsigned: true }),
  agentId: bigint("agentId", { mode: "number", unsigned: true }),
  direction: mysqlEnum("direction", ["inbound", "outbound"]).notNull(),
  status: mysqlEnum("status", ["queued", "ringing", "in_progress", "completed", "failed", "missed"]).default("queued").notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  clientName: varchar("clientName", { length: 255 }),
  duration: int("duration").default(0).notNull(),
  emotionScore: int("emotionScore").default(50).notNull(),
  emotionLabel: varchar("emotionLabel", { length: 50 }),
  transcript: text("transcript"),
  recordingUrl: text("recordingUrl"),
  outcome: mysqlEnum("outcome", ["success", "follow_up", "no_answer", "rejected", "voicemail", "in_progress"]).default("in_progress").notNull(),
  startedAt: timestamp("startedAt"),
  endedAt: timestamp("endedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Call = typeof calls.$inferSelect;
export type InsertCall = typeof calls.$inferInsert;

// Transcript entries — записи транскрипции
export const transcriptEntries = mysqlTable("transcript_entries", {
  id: serial("id").primaryKey(),
  callId: bigint("callId", { mode: "number", unsigned: true }).notNull(),
  speaker: mysqlEnum("speaker", ["ai", "client"]).notNull(),
  text: text("text").notNull(),
  emotion: varchar("emotion", { length: 50 }),
  timestamp: int("timestamp").notNull(), // seconds from call start
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TranscriptEntry = typeof transcriptEntries.$inferSelect;
export type InsertTranscriptEntry = typeof transcriptEntries.$inferInsert;

// Appointments — записи на встречи
export const appointments = mysqlTable("appointments", {
  id: serial("id").primaryKey(),
  callId: bigint("callId", { mode: "number", unsigned: true }),
  clientId: bigint("clientId", { mode: "number", unsigned: true }).notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  scheduledFor: timestamp("scheduledFor").notNull(),
  purpose: varchar("purpose", { length: 255 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["scheduled", "confirmed", "cancelled", "completed", "no_show"]).default("scheduled").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;

// Secret Shopper Calls — тайный покупатель
export const secretShopperCalls = mysqlTable("secret_shopper_calls", {
  id: serial("id").primaryKey(),
  agentId: bigint("agentId", { mode: "number", unsigned: true }),
  shopPhone: varchar("shopPhone", { length: 50 }).notNull(),
  shopName: varchar("shopName", { length: 255 }),
  shopType: mysqlEnum("shopType", ["retail", "restaurant", "service", "online", "other"]).default("retail").notNull(),
  productName: varchar("productName", { length: 255 }),
  scenario: mysqlEnum("scenario", ["price_inquiry", "product_quality", "purchase_flow", "complaint", "consultation"]).default("price_inquiry").notNull(),
  status: mysqlEnum("status", ["queued", "calling", "in_progress", "completed", "failed"]).default("queued").notNull(),
  duration: int("duration").default(0).notNull(),
  transcript: text("transcript"),
  recordingUrl: text("recordingUrl"),
  // Evaluation scores (1-10)
  politenessScore: int("politenessScore"),      // Вежливость
  knowledgeScore: int("knowledgeScore"),          // Знание товара
  helpfulnessScore: int("helpfulnessScore"),      // Готовность помочь
  clarityScore: int("clarityScore"),              // Ясность ответов
  overallScore: int("overallScore"),              // Общая оценка
  // Details
  greeting: text("greeting"),                     // Как поздоровались
  objections: text("objections"),                 // Возражения/вопросы
  recommendations: text("recommendations"),       // Что порекомендовали
  followUp: text("followUp"),                     // Обещали ли перезвонить
  summary: text("summary"),                       // Итоговый отчёт
  startedAt: timestamp("startedAt"),
  endedAt: timestamp("endedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SecretShopperCall = typeof secretShopperCalls.$inferSelect;
export type InsertSecretShopperCall = typeof secretShopperCalls.$inferInsert;
