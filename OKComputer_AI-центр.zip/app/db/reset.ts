import { getDb } from "../api/queries/connection";
import { sql } from "drizzle-orm";

async function reset() {
  const db = getDb();
  await db.execute(sql`DROP TABLE IF EXISTS transcript_entries, appointments, calls, campaigns, clients, agents, users`);
  console.log("All tables dropped");
}

reset().catch(console.error);
