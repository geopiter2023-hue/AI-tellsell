// Relations are defined here if needed for Drizzle relational queries
// Currently using simple queries without relations
