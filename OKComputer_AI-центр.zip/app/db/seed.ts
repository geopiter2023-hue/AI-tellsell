import { getDb } from "../api/queries/connection";
import { agents, clients, campaigns, calls, appointments, transcriptEntries, secretShopperCalls } from "./schema";

async function seed() {
  const db = getDb();

  // Seed agents
  const agentData = [
    { name: "Viktoria AI", voice: "female-warm", language: "ru-RU", emotionProfile: "friendly" as const, greetingScript: "Алло! Добрый день. Меня зовут Виктория, я инновационный сотрудник на искусственном интеллекте.", status: "active" as const, callsHandled: 347, successRate: 78 },
    { name: "Maxim AI", voice: "male-professional", language: "ru-RU", emotionProfile: "professional" as const, greetingScript: "Здравствуйте, меня зовут Максим. Я ваш AI-ассистент.", status: "active" as const, callsHandled: 198, successRate: 65 },
    { name: "Elena AI", voice: "female-calm", language: "ru-RU", emotionProfile: "calm" as const, greetingScript: "Добрый день. Меня зовут Елена, я AI-менеджер.", status: "paused" as const, callsHandled: 89, successRate: 82 },
  ];

  for (const agent of agentData) {
    await db.insert(agents).values(agent);
  }

  // Seed clients
  const clientData = [
    { name: "Анатолий Петров", phone: "+7 (999) 123-45-67", email: "anatoly@example.com", company: "ООО СтройГрад", status: "active" as const, totalCalls: 3, notes: "Интересуется AI-решениями" },
    { name: "Марина Соколова", phone: "+7 (999) 234-56-78", email: "marina@example.com", company: "ИП Соколова", status: "lead" as const, totalCalls: 1, notes: "Первая встреча назначена" },
    { name: "Дмитрий Козлов", phone: "+7 (999) 345-67-89", email: "dmitry@example.com", company: "ТехноСфера", status: "active" as const, totalCalls: 5, notes: "Постоянный клиент" },
    { name: "Елена Волкова", phone: "+7 (999) 456-78-90", email: "elena@example.com", company: "АльфаГрупп", status: "lead" as const, totalCalls: 0, notes: "Новый лид из CRM" },
    { name: "Игорь Смирнов", phone: "+7 (999) 567-89-01", email: "igor@example.com", company: "БетаКорп", status: "inactive" as const, totalCalls: 2, notes: "Не отвечает на звонки" },
    { name: "Ольга Новикова", phone: "+7 (999) 678-90-12", email: "olga@example.com", company: "ГаммаЛтд", status: "active" as const, totalCalls: 4, notes: "Заинтересована в интеграции" },
  ];

  for (const client of clientData) {
    await db.insert(clients).values(client);
  }

  // Seed campaigns
  const campaignData = [
    { name: "Апрельский обзвон — B2B", description: "Обзвон клиентов по базе B2B с предложением AI-решений", type: "outbound" as const, status: "running" as const, agentId: 1, script: "Представьтесь как AI-агент. Предложите замену отдела продаж. Подчеркните экономию.", targetCount: 500, callsMade: 347, callsAnswered: 289, successRate: 78 },
    { name: "Входящая линия — Поддержка", description: "Приём входящих звонков от клиентов", type: "inbound" as const, status: "running" as const, agentId: 2, script: "Приветствие. Определите запрос. Направьте к нужному специалисту или решите вопрос.", targetCount: 1000, callsMade: 842, callsAnswered: 810, successRate: 92 },
    { name: "Реактивация старых клиентов", description: "Обзвон неактивных клиентов за последние 6 месяцев", type: "outbound" as const, status: "paused" as const, agentId: 1, script: "Узнайте причины ухода. Предложите новые условия. Запишите на встречу.", targetCount: 200, callsMade: 89, callsAnswered: 67, successRate: 45 },
  ];

  for (const campaign of campaignData) {
    await db.insert(campaigns).values(campaign);
  }

  // Seed active calls
  const callData = [
    { campaignId: 1, clientId: 1, agentId: 1, direction: "outbound" as const, status: "in_progress" as const, phone: "+7 (999) 123-45-67", clientName: "Анатолий Петров", duration: 145, emotionScore: 72, emotionLabel: "joy", transcript: "Алло! Добрый день. Меня зовут Виктория... Я инновационный сотрудник на искусственном интеллекте...", outcome: "in_progress" as const, startedAt: new Date(Date.now() - 145000) },
    { campaignId: 1, clientId: 2, agentId: 1, direction: "outbound" as const, status: "in_progress" as const, phone: "+7 (999) 234-56-78", clientName: "Марина Соколова", duration: 89, emotionScore: 55, emotionLabel: "calm", transcript: "Добрый день, Марина. Я звоню по поводу наших AI-решений...", outcome: "in_progress" as const, startedAt: new Date(Date.now() - 89000) },
    { campaignId: 2, clientId: 3, agentId: 2, direction: "inbound" as const, status: "in_progress" as const, phone: "+7 (999) 345-67-89", clientName: "Дмитрий Козлов", duration: 234, emotionScore: 85, emotionLabel: "joy", transcript: "Здравствуйте, у меня вопрос по интеграции с CRM...", outcome: "in_progress" as const, startedAt: new Date(Date.now() - 234000) },
    { campaignId: 1, clientId: null, agentId: 1, direction: "outbound" as const, status: "ringing" as const, phone: "+7 (999) 456-78-90", clientName: "Елена Волкова", duration: 0, emotionScore: 50, emotionLabel: "calm", outcome: "in_progress" as const },
    { campaignId: 1, clientId: null, agentId: 1, direction: "outbound" as const, status: "queued" as const, phone: "+7 (999) 567-89-01", clientName: "Игорь Смирнов", duration: 0, emotionScore: 50, outcome: "in_progress" as const },
  ];

  for (const call of callData) {
    await db.insert(calls).values(call);
  }

  // Seed transcript entries
  const transcriptData = [
    { callId: 1, speaker: "ai" as const, text: "Алло! Добрый день. Меня зовут Виктория, я инновационный сотрудник на искусственном интеллекте.", emotion: "joy", timestamp: 0 },
    { callId: 1, speaker: "client" as const, text: "Здравствуйте. Интересно, а вы уже звонили нам раньше?", emotion: "calm", timestamp: 8 },
    { callId: 1, speaker: "ai" as const, text: "Нет, это наш первый контакт. Я звоню вам с уникальным предложением — заменить ваш отдел продаж на одного AI-агента.", emotion: "joy", timestamp: 14 },
    { callId: 1, speaker: "client" as const, text: "Звучит любопытно. Расскажите подробнее.", emotion: "joy", timestamp: 22 },
    { callId: 1, speaker: "ai" as const, text: "Я могу обрабатывать неограниченное количество звонков 24/7, без перерывов и выходных. Это сэкономит вам до 70% на зарплате менеджеров.", emotion: "joy", timestamp: 28 },
    { callId: 1, speaker: "client" as const, text: "А как насчёт эмоциональной окраски? Можете менять тон во время разговора?", emotion: "calm", timestamp: 42 },
    { callId: 1, speaker: "ai" as const, text: "Конечно! Я могу адаптировать эмоциональную окраску в реальном времени. Хотите, я продемонстрирую?", emotion: "joy", timestamp: 50 },
    { callId: 2, speaker: "ai" as const, text: "Добрый день, Марина! Я Виктория, ваш AI-менеджер. Как ваши дела сегодня?", emotion: "joy", timestamp: 0 },
    { callId: 2, speaker: "client" as const, text: "Добрый. Всё хорошо, спасибо.", emotion: "calm", timestamp: 6 },
    { callId: 2, speaker: "ai" as const, text: "Отлично! Я звоню, чтобы рассказать о нашем новом сервисе автоматизации звонков. Он поможет вашему бизнесу расти быстрее.", emotion: "joy", timestamp: 10 },
  ];

  for (const entry of transcriptData) {
    await db.insert(transcriptEntries).values(entry);
  }

  // Seed appointments
  const appointmentData = [
    { callId: 1, clientId: 1, clientName: "Анатолий Петров", phone: "+7 (999) 123-45-67", scheduledFor: new Date(Date.now() + 86400000 * 2), purpose: "Демонстрация AI-агента", notes: "Показать живую демонстрацию. Клиент заинтересован.", status: "scheduled" as const },
    { callId: 2, clientId: 2, clientName: "Марина Соколова", phone: "+7 (999) 234-56-78", scheduledFor: new Date(Date.now() + 86400000 * 3), purpose: "Презентация решения", notes: "Подготовить индивидуальное предложение", status: "scheduled" as const },
    { callId: null, clientId: 3, clientName: "Дмитрий Козлов", phone: "+7 (999) 345-67-89", scheduledFor: new Date(Date.now() + 86400000), purpose: "Техническая консультация", notes: "Обсудить интеграцию с CRM", status: "confirmed" as const },
  ];

  for (const appt of appointmentData) {
    await db.insert(appointments).values(appt);
  }

  // Seed secret shopper calls
  const shopperData = [
    {
      shopPhone: "+7 (495) 123-45-67",
      shopName: "ТехноПарк (Тверская)",
      shopType: "retail" as const,
      productName: "iPhone 16 Pro",
      scenario: "price_inquiry" as const,
      status: "completed" as const,
      duration: 185,
      transcript: "Виктория: Здравствуйте, подскажите пожалуйста, сколько стоит iPhone 16 Pro 256GB?\nМенеджер: Добрый день! Сейчас уточню... iPhone 16 Pro 256GB стоит 149 990 рублей.\nВиктория: А есть скидки или рассрочка?\nМенеджер: Да, конечно! Рассрочка на 12 месяцев без переплаты. Также скидка 5% при оплате картой Тинькофф.\nВиктория: А гарантия какая?\nМенеджер: Официальная гарантия Apple 1 год + мы даём дополнительный год сервисного обслуживания бесплатно.\nВиктория: Спасибо большое, подумаю.\nМенеджер: Обращайтесь! Если будут вопросы — звоните, рады помочь.",
      politenessScore: 9,
      knowledgeScore: 8,
      helpfulnessScore: 9,
      clarityScore: 9,
      overallScore: 9,
      greeting: "Добрый день! Улыбнулся, поздоровался тепло",
      objections: "Возражений не было, предложил рассрочку proactively",
      recommendations: "Рекомендовал рассрочку, карту Тинькофф, доп. гарантию",
      followUp: "Предложил перезвонить через день",
      summary: "Отличное обслуживание. Менеджер был вежлив, хорошо разбирается в продукте, предложил выгодные условия. Рекомендуют магазин.",
      startedAt: new Date(Date.now() - 86400000),
      endedAt: new Date(Date.now() - 86400000 + 185000),
    },
    {
      shopPhone: "+7 (495) 234-56-78",
      shopName: "Бургер Клаб (Арбат)",
      shopType: "restaurant" as const,
      productName: "Бизнес-ланч",
      scenario: "product_quality" as const,
      status: "completed" as const,
      duration: 142,
      transcript: "Виктория: Добрый день, уточните пожалуйста, что входит в бизнес-ланч?\nОфициант: Алло... эээ... сейчас... У нас есть бургеры, картошка и напиток.\nВиктория: А какие бургеры на выбор?\nОфициант: Ну... обычные бургеры. Классический и чизбургер.\nВиктория: А есть салаты?\nОфициант: Эээ... нет, салатов нет в ланче.\nВиктория: Понятно. А работаете до скольки?\nОфициант: До 23:00.\nВиктория: Спасибо.",
      politenessScore: 4,
      knowledgeScore: 3,
      helpfulnessScore: 3,
      clarityScore: 4,
      overallScore: 4,
      greeting: "Сухой ответ без приветствия",
      objections: "Не знал состав ланча, не предложил альтернатив",
      recommendations: "Никаких рекомендаций не дал",
      followUp: "Не предложил ничего",
      summary: "Низкое качество обслуживания. Официант не знал меню, был невежлив, не предложил альтернатив. Не рекомендуют.",
      startedAt: new Date(Date.now() - 172800000),
      endedAt: new Date(Date.now() - 172800000 + 142000),
    },
    {
      shopPhone: "+7 (499) 345-67-89",
      shopName: "Сервисный центр AppleFix",
      shopType: "service" as const,
      productName: "Замена экрана iPhone",
      scenario: "consultation" as const,
      status: "completed" as const,
      duration: 210,
      transcript: "Виктория: Здравствуйте, у меня разбился экран iPhone 15, сколько будет стоить замена?\nМастер: Добрый день! Замена оригинального экрана iPhone 15 — 45 000 рублей, неоригинал — 25 000.\nВиктория: В чём разница между оригиналом и неоригиналом?\nМастер: Оригинал — заводская деталь с гарантией Apple. Неоригинал — качественная копия, гарантия нашего центра 6 месяцев. Яркость чуть ниже, но глазу незаметно.\nВиктория: А сколько времени займёт?\nМастер: 2-3 часа. Можете подождать в нашем зале или оставить телефон и забрать вечером.\nВиктория: А можно ли записаться?\nМастер: Конечно! Записываю вас. На завтра в 11:00 удобно? Также дам скидку 10% за предварительную запись.\nВиктория: Отлично, спасибо!\nМастер: До завтра! Приходите, всё сделаем быстро.",
      politenessScore: 9,
      knowledgeScore: 10,
      helpfulnessScore: 10,
      clarityScore: 9,
      overallScore: 10,
      greeting: "Добрый день! Теплый, профессиональный тон",
      objections: "Подробно объяснил разницу между оригиналом и копией",
      recommendations: "Предложил оригинал и неоригинал, запись со скидкой, альтернативы по времени",
      followUp: "Записал на завтра, предложил скидку 10%",
      summary: "Великолепное обслуживание! Мастер профессионален, отлично разбирается в продукте, предложил удобные варианты. Обязательно рекомендуют.",
      startedAt: new Date(Date.now() - 259200000),
      endedAt: new Date(Date.now() - 259200000 + 210000),
    },
    {
      shopPhone: "+7 (495) 456-78-90",
      shopName: "Эльдорадо (Ходынка)",
      shopType: "retail" as const,
      productName: "Samsung Galaxy S24",
      scenario: "purchase_flow" as const,
      status: "queued" as const,
      duration: 0,
    },
    {
      shopPhone: "+7 (495) 567-89-01",
      shopName: "Мир Пиццы",
      shopType: "restaurant" as const,
      productName: "Доставка пиццы",
      scenario: "complaint" as const,
      status: "queued" as const,
      duration: 0,
    },
  ];

  for (const call of shopperData) {
    await db.insert(secretShopperCalls).values(call);
  }

  console.log("Seed completed successfully!");
}

seed().catch(console.error);
