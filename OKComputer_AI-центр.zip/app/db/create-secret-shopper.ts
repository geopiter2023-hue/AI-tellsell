import { getDb } from "../api/queries/connection";
import { sql } from "drizzle-orm";

async function createTable() {
  const db = getDb();
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS secret_shopper_calls (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      agentId BIGINT UNSIGNED,
      shopPhone VARCHAR(50) NOT NULL,
      shopName VARCHAR(255),
      shopType ENUM('retail','restaurant','service','online','other') DEFAULT 'retail' NOT NULL,
      productName VARCHAR(255),
      scenario ENUM('price_inquiry','product_quality','purchase_flow','complaint','consultation') DEFAULT 'price_inquiry' NOT NULL,
      status ENUM('queued','calling','in_progress','completed','failed') DEFAULT 'queued' NOT NULL,
      duration INT DEFAULT 0 NOT NULL,
      transcript TEXT,
      recordingUrl TEXT,
      politenessScore INT,
      knowledgeScore INT,
      helpfulnessScore INT,
      clarityScore INT,
      overallScore INT,
      greeting TEXT,
      objections TEXT,
      recommendations TEXT,
      followUp TEXT,
      summary TEXT,
      startedAt TIMESTAMP,
      endedAt TIMESTAMP,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    )
  `);
  console.log("✅ Таблица secret_shopper_calls создана!");
}

createTable().catch(console.error);
