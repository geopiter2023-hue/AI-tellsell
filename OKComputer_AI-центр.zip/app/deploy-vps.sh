#!/bin/bash
# AI Call Center — Автоматический деплой на VPS
# Запуск: bash deploy-vps.sh

set -e

echo "═══════════════════════════════════════════"
echo "🚀 AI Call Center — Деплой на VPS"
echo "═══════════════════════════════════════════"

# === КОНФИГУРАЦИЯ ===
APP_NAME="ai-call-center"
APP_DIR="/var/www/$APP_NAME"
DOMAIN=""  # Оставьте пустым для IP, или введите домен
NODE_VERSION="20"
DB_NAME="ai_call_center"
DB_USER="aicallcenter"
DB_PASS="$(openssl rand -base64 24 | tr -d '=+/')"

# === ЦВЕТА ===
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# === ФУНКЦИИ ===
log_step() {
    echo ""
    echo -e "${YELLOW}▶ $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
}

# === ШАГ 0: ПРОВЕРКА ===
log_step "Проверка системы..."

if [ "$EUID" -ne 0 ]; then 
    log_error "Запустите скрипт с sudo: sudo bash deploy-vps.sh"
    exit 1
fi

# Определить дистрибутив
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
else
    log_error "Не удалось определить ОС"
    exit 1
fi

if [[ "$OS" != *"Ubuntu"* ]] && [[ "$OS" != *"Debian"* ]]; then
    log_error "Скрипт поддерживает только Ubuntu/Debian"
    exit 1
fi

IP_ADDRESS=$(hostname -I | awk '{print $1}')
log_success "ОС: $OS, IP: $IP_ADDRESS"

# === ШАГ 1: ОБНОВЛЕНИЕ ===
log_step "Обновление системы..."
apt update && apt upgrade -y
log_success "Система обновлена"

# === ШАГ 2: УСТАНОВКА NODE.JS ===
log_step "Установка Node.js $NODE_VERSION..."

if ! command -v node &> /dev/null || [ "$(node -v | cut -d'v' -f2 | cut -d'.' -f1)" != "$NODE_VERSION" ]; then
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
    apt install -y nodejs
fi

log_success "Node.js $(node -v) установлен"

# === ШАГ 3: УСТАНОВКА NGINX ===
log_step "Установка Nginx..."
apt install -y nginx
systemctl enable nginx
log_success "Nginx установлен"

# === ШАГ 4: УСТАНОВКА MYSQL ===
log_step "Установка MySQL..."
apt install -y mysql-server
systemctl enable mysql
systemctl start mysql

# Настройка MySQL
mysql -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mysql -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"

log_success "MySQL настроен. База: $DB_NAME"

# === ШАГ 5: УСТАНОВКА PM2 ===
log_step "Установка PM2..."
npm install -g pm2
pm2 startup systemd -u root --hp /root
log_success "PM2 установлен"

# === ШАГ 6: КОПИРОВАНИЕ ФАЙЛОВ ===
log_step "Копирование файлов приложения..."

mkdir -p $APP_DIR
cp -r dist/ $APP_DIR/
cp package.json $APP_DIR/
cp package-lock.json $APP_DIR/
cp drizzle.config.ts $APP_DIR/
cp tsconfig.server.json $APP_DIR/
cp -r db/ $APP_DIR/
cp -r contracts/ $APP_DIR/

cd $APP_DIR

# === ШАГ 7: УСТАНОВКА ЗАВИСИМОСТЕЙ ===
log_step "Установка зависимостей..."
npm ci --only=production
log_success "Зависимости установлены"

# === ШАГ 8: СОЗДАНИЕ .env ===
log_step "Создание конфигурации..."

cat > $APP_DIR/.env << EOF
DATABASE_URL=mysql://${DB_USER}:${DB_PASS}@localhost:3306/${DB_NAME}
OWNER_UNION_ID=
VITE_KIMI_AUTH_URL=https://kimi-auth.moonshot.cn
VITE_APP_ID=
APP_SECRET=$(openssl rand -base64 32)
VAPI_API_KEY=
VAPI_WEBHOOK_SECRET=ai-call-center-webhook-secret-$(openssl rand -hex 8)
VITE_APP_URL=http://${IP_ADDRESS}:3000
NODE_ENV=production
PORT=3000
EOF

log_success ".env создан"

# === ШАГ 9: СИНХРОНИЗАЦИЯ БАЗЫ ДАННЫХ ===
log_step "Синхронизация базы данных..."
cd $APP_DIR
npx drizzle-kit push --force 2>&1 || true
log_success "База данных готова"

# === ШАГ 10: НАСТРОЙКА NGINX ===
log_step "Настройка Nginx..."

if [ -n "$DOMAIN" ]; then
    # Конфиг с доменом
    cat > /etc/nginx/sites-available/$APP_NAME << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    location /api/sse/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Connection '';
        proxy_buffering off;
        proxy_cache off;
        chunked_transfer_encoding off;
    }
}
EOF
else
    # Конфиг с IP
    cat > /etc/nginx/sites-available/$APP_NAME << EOF
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    location /api/sse/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Connection '';
        proxy_buffering off;
        proxy_cache off;
        chunked_transfer_encoding off;
    }
}
EOF
fi

rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx

log_success "Nginx настроен"

# === ШАГ 11: ЗАПУСК ПРИЛОЖЕНИЯ ===
log_step "Запуск приложения..."

cd $APP_DIR
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'ai-call-center',
    script: './dist/boot.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    max_memory_restart: '512M',
    restart_delay: 3000,
    max_restarts: 5,
    min_uptime: '10s',
    watch: false,
    kill_timeout: 5000,
    listen_timeout: 10000
  }]
};
EOF

mkdir -p logs
pm2 delete ai-call-center 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save

log_success "Приложение запущено!"

# === ШАГ 12: SSL (Let's Encrypt) ===
if [ -n "$DOMAIN" ]; then
    log_step "Установка SSL (Let's Encrypt)..."
    apt install -y certbot python3-certbot-nginx
    certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN || true
    log_success "SSL установлен"
fi

# === ШАГ 13: ФАЙЕРВОЛ ===
log_step "Настройка файервола..."
apt install -y ufw
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 'Nginx Full'
ufw --force enable
log_success "Файервол настроен"

# === ИТОГ ===
echo ""
echo "═══════════════════════════════════════════"
echo -e "${GREEN}🎉 ДЕПЛОЙ ЗАВЕРШЁН!${NC}"
echo "═══════════════════════════════════════════"
echo ""
echo "📍 Доступ:"
if [ -n "$DOMAIN" ]; then
    echo "   https://$DOMAIN"
else
    echo "   http://$IP_ADDRESS"
fi
echo ""
echo "📁 Директория: $APP_DIR"
echo "🗄  База данных: $DB_NAME"
echo "🔐 MySQL пароль: $DB_PASS"
echo ""
echo "📋 Команды управления:"
echo "   pm2 status           — статус"
echo "   pm2 logs             — логи"
echo "   pm2 restart all      — перезапуск"
echo "   pm2 monit            — мониторинг"
echo ""
echo "📋 Nginx:"
echo "   nginx -t             — проверка конфига"
echo "   systemctl restart nginx — перезапуск"
echo ""
echo -e "${YELLOW}⚠️  ВАЖНО: Отредактируйте .env:${NC}"
echo "   nano $APP_DIR/.env"
echo "   Добавьте VAPI_API_KEY для звонков"
echo ""
