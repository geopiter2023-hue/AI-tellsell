import { useEffect, useRef, useState, useCallback } from "react";

interface CallEvent {
  id: number;
  clientName: string | null;
  phone: string;
  status: string;
  duration: number;
  emotionLabel: string | null;
  direction: string;
}

interface TranscriptLineEvent {
  callId: number;
  speaker: "ai" | "client";
  text: string;
  emotion: string;
  elapsedSeconds: number;
}

interface LiveEvent {
  type: "connected" | "call_started" | "call_connected" | "transcript_line" | "call_completed";
  call?: CallEvent;
  callId?: number;
  speaker?: "ai" | "client";
  text?: string;
  emotion?: string;
  elapsedSeconds?: number;
  duration?: number;
  outcome?: string;
}

export function useLiveCalls() {
  const [isConnected, setIsConnected] = useState(false);
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const [activeCalls, setActiveCalls] = useState<CallEvent[]>([]);
  const [latestTranscript, setLatestTranscript] = useState<TranscriptLineEvent | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  const connect = useCallback(() => {
    if (eventSourceRef.current) return;

    const es = new EventSource("/api/sse/calls");
    eventSourceRef.current = es;

    es.onopen = () => {
      setIsConnected(true);
    };

    es.onmessage = (event) => {
      try {
        const data: LiveEvent = JSON.parse(event.data);
        setEvents((prev) => [...prev.slice(-50), data]);

        switch (data.type) {
          case "call_started":
            if (data.call) {
              setActiveCalls((prev) => [...prev, data.call!]);
            }
            break;
          case "call_connected":
            setActiveCalls((prev) =>
              prev.map((c) => (c.id === data.callId ? { ...c, status: "in_progress" } : c))
            );
            break;
          case "transcript_line":
            if (data.callId && data.speaker && data.text) {
              setLatestTranscript({
                callId: data.callId,
                speaker: data.speaker,
                text: data.text,
                emotion: data.emotion || "neutral",
                elapsedSeconds: data.elapsedSeconds || 0,
              });
              // Update emotion for active call
              setActiveCalls((prev) =>
                prev.map((c) =>
                  c.id === data.callId
                    ? { ...c, emotionLabel: data.emotion || c.emotionLabel, duration: data.elapsedSeconds || c.duration }
                    : c
                )
              );
            }
            break;
          case "call_completed":
            setActiveCalls((prev) => prev.filter((c) => c.id !== data.callId));
            break;
        }
      } catch {
        // Ignore parse errors
      }
    };

    es.onerror = () => {
      setIsConnected(false);
      eventSourceRef.current = null;
      // Reconnect after 3 seconds
      setTimeout(connect, 3000);
    };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
    };
  }, [connect]);

  return { isConnected, events, activeCalls, latestTranscript };
}
