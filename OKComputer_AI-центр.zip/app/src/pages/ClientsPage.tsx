import { trpc } from "@/providers/trpc";
import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Users, Phone, Mail, Building2, Plus, UserCheck, UserX, User } from "lucide-react";
import { StatBadge } from "@/components/StatBadge";

const statusConfig: Record<string, { color: string; bg: string; label: string }> = {
  lead: { color: "#F59E0B", bg: "rgba(245, 158, 11, 0.15)", label: "Лид" },
  active: { color: "#22C55E", bg: "rgba(34, 197, 94, 0.15)", label: "Активный" },
  inactive: { color: "#6B7280", bg: "rgba(107, 114, 128, 0.15)", label: "Неактивный" },
  blacklisted: { color: "#EF4444", bg: "rgba(239, 68, 68, 0.15)", label: "ЧС" },
};

export function ClientsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: clients, isLoading } = trpc.clients.list.useQuery();
  const { data: stats } = trpc.clients.stats.useQuery();

  const filteredClients = clients?.filter((client) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      client.name.toLowerCase().includes(q) ||
      client.phone.includes(q) ||
      client.email?.toLowerCase().includes(q) ||
      client.company?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="h-full flex flex-col gap-3 md:gap-4">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <h1 className="font-display text-xl md:text-3xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>
          Клиенты
        </h1>
        <button className="flex items-center gap-2 px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm font-medium transition-all" style={{ background: "rgba(217, 70, 239, 0.15)", border: "1px solid rgba(217, 70, 239, 0.3)", color: "#D946EF" }}>
          <Plus size={14} />
          <span className="hidden sm:inline">Добавить</span>
        </button>
      </motion.div>

      {/* Stats */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
        <StatBadge icon={<Users size={14} />} label="Всего" value={stats?.total ?? 0} color="#D946EF" />
        <StatBadge icon={<User size={14} />} label="Лиды" value={stats?.leads ?? 0} color="#F59E0B" />
        <StatBadge icon={<UserCheck size={14} />} label="Активные" value={stats?.active ?? 0} color="#22C55E" />
        <StatBadge icon={<UserX size={14} />} label="Неактивные" value={stats?.inactive ?? 0} color="#6B7280" />
      </motion.div>

      {/* Search */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="glass-panel flex items-center gap-2 md:gap-3 px-3 md:px-4 py-2">
        <Search size={16} style={{ color: "var(--text-secondary)" }} />
        <input type="text" placeholder="Поиск клиентов..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="flex-1 bg-transparent text-xs md:text-sm outline-none placeholder:text-[#A855F7]/50" style={{ color: "var(--text-primary)" }} />
      </motion.div>

      {/* Client List */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-panel flex-1 overflow-hidden flex flex-col">
        {/* Desktop header */}
        <div className="hidden md:grid grid-cols-12 gap-4 px-5 py-3 text-xs font-medium tracking-wider uppercase border-b" style={{ borderColor: "var(--border-glass)", color: "var(--text-secondary)" }}>
          <div className="col-span-3">Имя</div>
          <div className="col-span-2">Телефон</div>
          <div className="col-span-2">Email</div>
          <div className="col-span-2">Компания</div>
          <div className="col-span-1">Статус</div>
          <div className="col-span-1">Звонки</div>
          <div className="col-span-1">Последний</div>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {isLoading ? (
            <div className="flex items-center justify-center h-32"><div className="w-6 h-6 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "var(--accent-neon)", borderTopColor: "transparent" }} /></div>
          ) : !filteredClients || filteredClients.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32">
              <Users size={24} style={{ color: "var(--text-secondary)" }} />
              <p className="text-sm mt-2" style={{ color: "var(--text-secondary)" }}>Клиенты не найдены</p>
            </div>
          ) : (
            <div className="flex flex-col">
              {filteredClients.map((client, index) => {
                const status = statusConfig[client.status] || statusConfig.lead;
                return (
                  <motion.div
                    key={client.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.03 }}
                    className="border-b transition-all hover:bg-[rgba(217,70,239,0.05)]"
                    style={{ borderColor: "rgba(147, 51, 234, 0.1)" }}
                  >
                    {/* Mobile card */}
                    <div className="md:hidden p-3 flex items-start gap-3">
                      <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0" style={{ background: "rgba(217, 70, 239, 0.15)", color: "#D946EF" }}>
                        {client.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium truncate" style={{ color: "var(--text-primary)" }}>{client.name}</span>
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0" style={{ background: status.bg, color: status.color }}>{status.label}</span>
                        </div>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="flex items-center gap-1 text-xs" style={{ color: "var(--text-secondary)" }}>
                            <Phone size={10} />{client.phone}
                          </span>
                          <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{client.totalCalls} звонков</span>
                        </div>
                      </div>
                    </div>

                    {/* Desktop row */}
                    <div className="hidden md:grid grid-cols-12 gap-4 px-5 py-3 items-center">
                      <div className="col-span-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: "rgba(217, 70, 239, 0.15)", color: "#D946EF" }}>
                            {client.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)}
                          </div>
                          <span className="text-sm font-medium truncate" style={{ color: "var(--text-primary)" }}>{client.name}</span>
                        </div>
                      </div>
                      <div className="col-span-2 flex items-center gap-1.5">
                        <Phone size={12} style={{ color: "var(--text-secondary)" }} />
                        <span className="text-sm truncate" style={{ color: "var(--text-primary)" }}>{client.phone}</span>
                      </div>
                      <div className="col-span-2 flex items-center gap-1.5">
                        <Mail size={12} style={{ color: "var(--text-secondary)" }} />
                        <span className="text-sm truncate" style={{ color: "var(--text-secondary)" }}>{client.email || "—"}</span>
                      </div>
                      <div className="col-span-2 flex items-center gap-1.5">
                        <Building2 size={12} style={{ color: "var(--text-secondary)" }} />
                        <span className="text-sm truncate" style={{ color: "var(--text-primary)" }}>{client.company || "—"}</span>
                      </div>
                      <div className="col-span-1">
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: status.bg, color: status.color }}>{status.label}</span>
                      </div>
                      <div className="col-span-1">
                        <span className="text-sm" style={{ color: "var(--text-primary)" }}>{client.totalCalls}</span>
                      </div>
                      <div className="col-span-1">
                        <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
                          {client.lastCallAt ? new Date(client.lastCallAt).toLocaleDateString("ru-RU", { month: "short", day: "numeric" }) : "Никогда"}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
