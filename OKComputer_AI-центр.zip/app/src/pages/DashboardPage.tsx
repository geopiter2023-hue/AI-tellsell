import { trpc } from "@/providers/trpc";
import { useLiveCalls } from "@/hooks/useLiveCalls";
import { EmotionalSphere } from "@/components/EmotionalSphere";
import { EmotionalSymbolPanel } from "@/components/EmotionalSymbolPanel";
import { CallListLive } from "@/components/CallListLive";
import { TranscriptPanelLive } from "@/components/TranscriptPanelLive";
import { VapiConnectPanel } from "@/components/VapiConnectPanel";
import { StatBadge } from "@/components/StatBadge";
import { motion } from "framer-motion";
import { Radio, Clock, PhoneCall, CheckCircle, Wifi, WifiOff } from "lucide-react";

export function DashboardPage() {
  const { data: stats } = trpc.calls.stats.useQuery(undefined, { refetchInterval: 3000 });
  const { activeCalls, isConnected, latestTranscript } = useLiveCalls();

  const liveCount = activeCalls.filter(
    (c) => c.status === "in_progress" || c.status === "ringing"
  ).length;

  return (
    <div className="h-full flex flex-col gap-3 md:gap-4">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-2"
      >
        <div className="flex items-center gap-3">
          <h1 className="font-display text-xl md:text-3xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>
            Активные звонки
          </h1>
          <div
            className="flex items-center gap-1.5 md:gap-2 px-2 md:px-3 py-0.5 md:py-1 rounded-full flex-shrink-0"
            style={{
              background: "rgba(239, 68, 68, 0.15)",
              border: "1px solid rgba(239, 68, 68, 0.3)",
            }}
          >
            <Radio size={12} className="text-red-400" />
            <span className="text-xs md:text-sm font-semibold text-red-400">{liveCount} в эфире</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {/* SSE Connection Status */}
          <div
            className="flex items-center gap-1.5 px-2 md:px-3 py-0.5 md:py-1 rounded-full"
            style={{
              background: isConnected ? "rgba(34, 197, 94, 0.1)" : "rgba(239, 68, 68, 0.1)",
              border: `1px solid ${isConnected ? "rgba(34, 197, 94, 0.2)" : "rgba(239, 68, 68, 0.2)"}`,
            }}
          >
            {isConnected ? (
              <Wifi size={10} className="text-green-400" />
            ) : (
              <WifiOff size={10} className="text-red-400" />
            )}
            <span className="text-xs" style={{ color: isConnected ? "#22C55E" : "#EF4444" }}>
              {isConnected ? "Live" : "Переподключение..."}
            </span>
          </div>
          <div className="font-display text-lg md:text-2xl font-bold tracking-tight hidden sm:block" style={{ color: "var(--text-secondary)" }}>
            {new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}
          </div>
        </div>
      </motion.div>

      {/* Stats Bar - 2x2 on mobile, row on desktop */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3"
      >
        <StatBadge icon={<Radio size={14} />} label="Активные" value={stats?.active ?? 0} color="#EF4444" />
        <StatBadge icon={<Clock size={14} />} label="В очереди" value={stats?.queued ?? 0} color="#F59E0B" />
        <StatBadge icon={<CheckCircle size={14} />} label="Завершено" value={stats?.completed ?? 0} color="#22C55E" />
        <StatBadge icon={<PhoneCall size={14} />} label="Всего" value={stats?.totalCalls ?? 0} color="#D946EF" />
      </motion.div>

      {/* Main Grid - stacked on mobile, side by side on desktop */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 md:gap-4 min-h-0">
        {/* Left Column - 3D Sphere + Transcript */}
        <div className="lg:col-span-7 flex flex-col gap-3 md:gap-4 min-h-0">
          {/* 3D Sphere Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="glass-panel flex-1 min-h-[200px] md:min-h-0 relative overflow-hidden"
          >
            <div className="absolute top-3 left-3 md:top-4 md:left-4 z-10">
              <span className="text-xs font-medium tracking-wider uppercase" style={{ color: "var(--text-secondary)" }}>
                ИИ Нейро-ядро
              </span>
            </div>
            <div className="absolute top-3 right-3 md:top-4 md:right-4 z-10">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "var(--accent-neon)" }} />
                <span className="text-xs hidden sm:inline" style={{ color: "var(--accent-neon)" }}>
                  {activeCalls.length > 0 ? "Обработка" : "Ожидание"}
                </span>
              </div>
            </div>
            <div className="h-full flex">
              <div className="flex-1">
                <EmotionalSphere />
              </div>
              <div className="w-20 md:w-32 border-l hidden sm:flex" style={{ borderColor: "var(--border-glass)" }}>
                <EmotionalSymbolPanel />
              </div>
            </div>
          </motion.div>

          {/* Transcript Panel - LIVE */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-panel h-40 md:h-48 flex flex-col"
          >
            <TranscriptPanelLive latestLine={latestTranscript} activeCall={activeCalls[0]} />
          </motion.div>
        </div>

        {/* Right Column - Call List + Vapi */}
        <div className="lg:col-span-5 flex flex-col gap-3 md:gap-4 min-h-0">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-panel flex-1 flex flex-col overflow-hidden min-h-[200px]"
          >
            <div className="p-3 md:p-4 border-b flex items-center justify-between" style={{ borderColor: "var(--border-glass)" }}>
              <h2 className="font-display text-sm md:text-lg font-semibold" style={{ color: "var(--text-primary)" }}>
                Очередь звонков
              </h2>
              {isConnected && (
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs text-green-400">Live</span>
                </div>
              )}
            </div>
            <div className="flex-1 overflow-y-auto scrollbar-thin p-2 md:p-3">
              <CallListLive calls={activeCalls} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <VapiConnectPanel />
          </motion.div>
        </div>
      </div>
    </div>
  );
}
