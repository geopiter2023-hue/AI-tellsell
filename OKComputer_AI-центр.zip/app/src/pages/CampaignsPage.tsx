import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import { Phone, Plus, Play, Pause, BarChart3, Clock, Target, Radio } from "lucide-react";
import { StatBadge } from "@/components/StatBadge";

const statusConfig: Record<string, { color: string; bg: string; label: string }> = {
  draft: { color: "#6B7280", bg: "rgba(107, 114, 128, 0.15)", label: "Черновик" },
  running: { color: "#22C55E", bg: "rgba(34, 197, 94, 0.15)", label: "Запущена" },
  paused: { color: "#F59E0B", bg: "rgba(245, 158, 11, 0.15)", label: "На паузе" },
  completed: { color: "#3B82F6", bg: "rgba(59, 130, 246, 0.15)", label: "Завершена" },
};

const typeConfig: Record<string, { color: string; icon: typeof Phone }> = {
  outbound: { color: "#D946EF", icon: Phone },
  inbound: { color: "#06B6D4", icon: Radio },
};

export function CampaignsPage() {
  const utils = trpc.useUtils();
  const { data: campaigns, isLoading } = trpc.campaigns.list.useQuery();
  const { data: stats } = trpc.campaigns.stats.useQuery();
  const toggleMutation = trpc.campaigns.toggleStatus.useMutation({
    onSuccess: () => { utils.campaigns.list.invalidate(); utils.campaigns.stats.invalidate(); },
  });

  return (
    <div className="h-full flex flex-col gap-3 md:gap-4">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <h1 className="font-display text-xl md:text-3xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>Кампании</h1>
        <button className="flex items-center gap-2 px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm font-medium" style={{ background: "rgba(217, 70, 239, 0.15)", border: "1px solid rgba(217, 70, 239, 0.3)", color: "#D946EF" }}>
          <Plus size={14} /><span className="hidden sm:inline">Новая кампания</span>
        </button>
      </motion.div>

      {/* Stats */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
        <StatBadge icon={<Target size={14} />} label="Всего" value={stats?.total ?? 0} color="#D946EF" />
        <StatBadge icon={<Play size={14} />} label="Запущено" value={stats?.running ?? 0} color="#22C55E" />
        <StatBadge icon={<Pause size={14} />} label="На паузе" value={stats?.paused ?? 0} color="#F59E0B" />
        <StatBadge icon={<Phone size={14} />} label="Звонков" value={stats?.totalCallsMade ?? 0} color="#06B6D4" />
      </motion.div>

      {/* Campaign Cards */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
          {isLoading ? (
            <div className="col-span-full flex items-center justify-center h-32"><div className="w-6 h-6 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "var(--accent-neon)", borderTopColor: "transparent" }} /></div>
          ) : !campaigns || campaigns.length === 0 ? (
            <div className="col-span-full flex flex-col items-center justify-center h-32"><Target size={24} style={{ color: "var(--text-secondary)" }} /><p className="text-sm mt-2" style={{ color: "var(--text-secondary)" }}>Кампаний пока нет</p></div>
          ) : (
            campaigns.map((campaign, index) => {
              const status = statusConfig[campaign.status] || statusConfig.draft;
              const typeInfo = typeConfig[campaign.type] || typeConfig.outbound;
              const TypeIcon = typeInfo.icon;
              const progress = campaign.targetCount > 0 ? Math.round((campaign.callsMade / campaign.targetCount) * 100) : 0;

              return (
                <motion.div key={campaign.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.08 }} className="glass-panel glass-panel-hover p-4 md:p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2 md:gap-3 min-w-0 flex-1">
                      <div className="w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${typeInfo.color}15`, color: typeInfo.color }}>
                        <TypeIcon size={16} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-sm font-semibold truncate" style={{ color: "var(--text-primary)" }}>{campaign.name}</h3>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: status.bg, color: status.color }}>{status.label}</span>
                          <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{campaign.type === "outbound" ? "Исходящая" : "Входящая"}</span>
                        </div>
                      </div>
                    </div>
                    <button onClick={() => toggleMutation.mutate({ id: campaign.id })} className="w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center flex-shrink-0 ml-2" style={{ background: campaign.status === "running" ? "rgba(245, 158, 11, 0.15)" : "rgba(34, 197, 94, 0.15)", color: campaign.status === "running" ? "#F59E0B" : "#22C55E" }}>
                      {campaign.status === "running" ? <Pause size={12} /> : <Play size={12} />}
                    </button>
                  </div>

                  {campaign.description && (
                    <p className="text-xs mb-3 line-clamp-2" style={{ color: "var(--text-secondary)" }}>{campaign.description}</p>
                  )}

                  {/* Progress bar */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>Прогресс</span>
                      <span className="text-xs font-medium" style={{ color: "var(--text-primary)" }}>{campaign.callsMade} / {campaign.targetCount}</span>
                    </div>
                    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(147, 51, 234, 0.1)" }}>
                      <motion.div className="h-full rounded-full" style={{ background: "linear-gradient(90deg, #D946EF, #9333EA)" }} initial={{ width: 0 }} animate={{ width: `${Math.min(progress, 100)}%` }} transition={{ duration: 1, delay: index * 0.1 }} />
                    </div>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-2 md:gap-3">
                    <div className="dark-well p-2 md:p-2.5 rounded-lg text-center">
                      <BarChart3 size={12} className="mx-auto mb-1" style={{ color: "var(--accent-neon)" }} />
                      <div className="font-display text-base md:text-lg font-bold" style={{ color: "var(--text-primary)" }}>{campaign.successRate}%</div>
                      <div className="text-xs" style={{ color: "var(--text-secondary)" }}>Успех</div>
                    </div>
                    <div className="dark-well p-2 md:p-2.5 rounded-lg text-center">
                      <Phone size={12} className="mx-auto mb-1" style={{ color: "var(--accent-cyan)" }} />
                      <div className="font-display text-base md:text-lg font-bold" style={{ color: "var(--text-primary)" }}>{campaign.callsAnswered}</div>
                      <div className="text-xs" style={{ color: "var(--text-secondary)" }}>Ответили</div>
                    </div>
                    <div className="dark-well p-2 md:p-2.5 rounded-lg text-center">
                      <Clock size={12} className="mx-auto mb-1" style={{ color: "var(--emotion-joy)" }} />
                      <div className="font-display text-sm md:text-lg font-bold" style={{ color: "var(--text-primary)" }}>
                        {new Date(campaign.createdAt).toLocaleDateString("ru-RU", { month: "short", day: "numeric" })}
                      </div>
                      <div className="text-xs" style={{ color: "var(--text-secondary)" }}>Создана</div>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </motion.div>
    </div>
  );
}
