import { trpc } from "@/providers/trpc";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, Phone, Star, Plus, Clock, ShoppingBag, UtensilsCrossed, Wrench, Globe, Package, MessageSquare, ThumbsUp, FileText } from "lucide-react";
import { StatBadge } from "@/components/StatBadge";

const shopTypeConfig: Record<string, { label: string; color: string; bg: string; icon: typeof ShoppingBag }> = {
  retail: { label: "Магазин", color: "#D946EF", bg: "rgba(217,70,239,0.15)", icon: ShoppingBag },
  restaurant: { label: "Ресторан", color: "#F59E0B", bg: "rgba(245,158,11,0.15)", icon: UtensilsCrossed },
  service: { label: "Сервис", color: "#06B6D4", bg: "rgba(6,182,212,0.15)", icon: Wrench },
  online: { label: "Онлайн", color: "#22C55E", bg: "rgba(34,197,94,0.15)", icon: Globe },
  other: { label: "Другое", color: "#6B7280", bg: "rgba(107,114,128,0.15)", icon: Package },
};

const scenarioConfig: Record<string, { label: string; desc: string }> = {
  price_inquiry: { label: "Узнать цену", desc: "Позвонить и узнать цену товара/услуги, сравнить с конкурентами" },
  product_quality: { label: "Качество товара", desc: "Узнать о качестве, материалах, гарантии" },
  purchase_flow: { label: "Процесс покупки", desc: "Проверить как оформляют заказ, доставку, оплату" },
  complaint: { label: "Жалоба", desc: "Позвонить с жалобой, проверить реакцию" },
  consultation: { label: "Консультация", desc: "Попросить совет по выбору товара" },
};

const statusConfig: Record<string, { color: string; bg: string; label: string }> = {
  queued: { color: "#6B7280", bg: "rgba(107,114,128,0.15)", label: "В очереди" },
  calling: { color: "#F59E0B", bg: "rgba(245,158,11,0.15)", label: "Звоним" },
  in_progress: { color: "#22C55E", bg: "rgba(34,197,94,0.15)", label: "В эфире" },
  completed: { color: "#3B82F6", bg: "rgba(59,130,246,0.15)", label: "Завершён" },
  failed: { color: "#EF4444", bg: "rgba(239,68,68,0.15)", label: "Ошибка" },
};

function StarRating({ value, max = 10 }: { value: number | null; max?: number }) {
  if (!value) return <span className="text-xs" style={{ color: "var(--text-secondary)" }}>—</span>;
  return (
    <div className="flex items-center gap-1">
      {[...Array(max)].map((_, i) => (
        <Star
          key={i}
          size={10}
          fill={i < value ? "#FACC15" : "transparent"}
          style={{ color: i < value ? "#FACC15" : "rgba(255,255,255,0.2)" }}
        />
      ))}
      <span className="text-xs font-medium ml-1" style={{ color: "#FACC15" }}>{value}/{max}</span>
    </div>
  );
}

export function SecretShopperPage() {
  const [showForm, setShowForm] = useState(false);
  const [showReport, setShowReport] = useState<number | null>(null);
  const [form, setForm] = useState({
    shopPhone: "",
    shopName: "",
    shopType: "retail" as const,
    productName: "",
    scenario: "price_inquiry" as const,
  });

  const { data: calls, isLoading } = trpc.secretShopper.list.useQuery();
  const { data: stats } = trpc.secretShopper.stats.useQuery();
  const utils = trpc.useUtils();

  const createMutation = trpc.secretShopper.create.useMutation({
    onSuccess: () => { utils.secretShopper.list.invalidate(); utils.secretShopper.stats.invalidate(); setShowForm(false); setForm({ shopPhone: "", shopName: "", shopType: "retail", productName: "", scenario: "price_inquiry" }); },
  });

  const selectedCall = calls?.find((c) => c.id === showReport);

  return (
    <div className="h-full flex flex-col gap-3 md:gap-4 overflow-y-auto scrollbar-thin">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Eye size={24} style={{ color: "#D946EF" }} />
          <h1 className="font-display text-xl md:text-3xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>Тайный покупатель</h1>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm font-medium" style={{ background: "rgba(217, 70, 239, 0.15)", border: "1px solid rgba(217, 70, 239, 0.3)", color: "#D946EF" }}>
          <Plus size={14} />{showForm ? "Закрыть" : "Новый звонок"}
        </button>
      </motion.div>

      {/* Description */}
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-xs md:text-sm" style={{ color: "var(--text-secondary)" }}>
        AI-агент звонит в магазины под видом покупателя, оценивает качество обслуживания и формирует отчёт
      </motion.p>

      {/* Stats */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
        <StatBadge icon={<Phone size={14} />} label="Всего проверок" value={stats?.total ?? 0} color="#D946EF" />
        <StatBadge icon={<ThumbsUp size={14} />} label="Завершено" value={stats?.completed ?? 0} color="#22C55E" />
        <StatBadge icon={<Star size={14} />} label="Средняя оценка" value={stats?.avgOverallScore ?? 0} color="#FACC15" suffix="/10" />
        <StatBadge icon={<MessageSquare size={14} />} label="Вежливость" value={stats?.avgPoliteness ?? 0} color="#06B6D4" suffix="/10" />
      </motion.div>

      {/* Create Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="glass-panel p-4 md:p-5">
              <h3 className="text-sm font-semibold mb-3" style={{ color: "var(--text-primary)" }}>Новый звонок тайного покупателя</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Телефон магазина *</label>
                  <input type="tel" placeholder="+7 495 123 45 67" value={form.shopPhone} onChange={(e) => setForm({ ...form, shopPhone: e.target.value })} className="w-full px-3 py-2 rounded-lg text-sm outline-none" style={{ background: "rgba(5,2,6,0.6)", border: "1px solid rgba(147,51,234,0.2)", color: "var(--text-primary)" }} />
                </div>
                <div>
                  <label className="text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Название магазина</label>
                  <input type="text" placeholder="Магазин Электроники" value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} className="w-full px-3 py-2 rounded-lg text-sm outline-none" style={{ background: "rgba(5,2,6,0.6)", border: "1px solid rgba(147,51,234,0.2)", color: "var(--text-primary)" }} />
                </div>
                <div>
                  <label className="text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Тип заведения</label>
                  <select value={form.shopType} onChange={(e) => setForm({ ...form, shopType: e.target.value as typeof form.shopType })} className="w-full px-3 py-2 rounded-lg text-sm outline-none" style={{ background: "rgba(5,2,6,0.6)", border: "1px solid rgba(147,51,234,0.2)", color: "var(--text-primary)" }}>
                    {Object.entries(shopTypeConfig).map(([key, { label }]) => <option key={key} value={key}>{label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Товар/услуга</label>
                  <input type="text" placeholder="iPhone 16 Pro" value={form.productName} onChange={(e) => setForm({ ...form, productName: e.target.value })} className="w-full px-3 py-2 rounded-lg text-sm outline-none" style={{ background: "rgba(5,2,6,0.6)", border: "1px solid rgba(147,51,234,0.2)", color: "var(--text-primary)" }} />
                </div>
              </div>

              {/* Scenario */}
              <label className="text-xs font-medium mt-3 mb-2 block" style={{ color: "var(--text-secondary)" }}>Сценарий звонка</label>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 mb-3">
                {Object.entries(scenarioConfig).map(([key, { label, desc }]) => (
                  <button key={key} onClick={() => setForm({ ...form, scenario: key as typeof form.scenario })} className="p-3 rounded-xl text-left transition-all" style={{ background: form.scenario === key ? "rgba(217,70,239,0.15)" : "rgba(5,2,6,0.4)", border: `1px solid ${form.scenario === key ? "rgba(217,70,239,0.4)" : "rgba(147,51,234,0.1)"}` }}>
                    <div className="text-xs md:text-sm font-medium" style={{ color: form.scenario === key ? "#D946EF" : "var(--text-primary)" }}>{label}</div>
                    <div className="text-[10px] md:text-xs mt-1" style={{ color: "var(--text-secondary)" }}>{desc}</div>
                  </button>
                ))}
              </div>

              <button onClick={() => form.shopPhone && createMutation.mutate(form)} disabled={!form.shopPhone || createMutation.isPending} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium disabled:opacity-40" style={{ background: "rgba(217,70,239,0.2)", border: "1px solid rgba(217,70,239,0.4)", color: "#D946EF" }}>
                {createMutation.isPending ? "Создание..." : "Создать задание"}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Call List */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="flex-1">
        <h2 className="font-display text-base md:text-lg font-semibold mb-2" style={{ color: "var(--text-primary)" }}>Задания тайного покупателя</h2>
        {isLoading ? (
          <div className="flex items-center justify-center h-32"><div className="w-6 h-6 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "var(--accent-neon)", borderTopColor: "transparent" }} /></div>
        ) : !calls || calls.length === 0 ? (
          <div className="glass-panel flex flex-col items-center justify-center py-12">
            <Eye size={32} style={{ color: "var(--text-secondary)" }} />
            <p className="text-sm mt-2" style={{ color: "var(--text-secondary)" }}>Нет заданий</p>
            <p className="text-xs mt-1" style={{ color: "var(--text-secondary)" }}>Нажмите "Новый звонок" чтобы начать</p>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {calls.map((call, index) => {
              const typeInfo = shopTypeConfig[call.shopType] || shopTypeConfig.other;
              const scenario = scenarioConfig[call.scenario] || scenarioConfig.price_inquiry;
              const status = statusConfig[call.status] || statusConfig.queued;
              const TypeIcon = typeInfo.icon;

              return (
                <motion.div key={call.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }} className="glass-panel p-3 md:p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2 md:gap-3 flex-1 min-w-0">
                      <div className="w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: typeInfo.bg, color: typeInfo.color }}>
                        <TypeIcon size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium truncate" style={{ color: "var(--text-primary)" }}>{call.shopName || call.shopPhone}</span>
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ background: status.bg, color: status.color }}>{status.label}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs flex-wrap">
                          <span style={{ color: "var(--text-secondary)" }}>{scenario.label}</span>
                          {call.productName && <span className="px-1.5 py-0.5 rounded" style={{ background: "rgba(147,51,234,0.1)", color: "#A855F7" }}>{call.productName}</span>}
                          <span className="flex items-center gap-1" style={{ color: "var(--text-secondary)" }}><Clock size={10} />{call.duration ? `${Math.floor(call.duration / 60)}:${(call.duration % 60).toString().padStart(2, "0")}` : "—"}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-2">
                      {call.overallScore && <StarRating value={call.overallScore} />}
                      <button onClick={() => setShowReport(showReport === call.id ? null : call.id)} className="text-xs px-2 py-1 rounded-lg flex items-center gap-1" style={{ background: "rgba(6,182,212,0.15)", color: "#06B6D4" }}>
                        <FileText size={10} />{showReport === call.id ? "Скрыть" : "Отчёт"}
                      </button>
                    </div>
                  </div>

                  {/* Report */}
                  <AnimatePresence>
                    {showReport === call.id && selectedCall && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <div className="mt-3 pt-3 border-t grid grid-cols-1 md:grid-cols-2 gap-3" style={{ borderColor: "var(--border-glass)" }}>
                          {/* Scores */}
                          {selectedCall.overallScore && (
                            <div className="space-y-2">
                              <h4 className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-secondary)" }}>Оценки</h4>
                              {[
                                { label: "Вежливость", value: selectedCall.politenessScore },
                                { label: "Знание товара", value: selectedCall.knowledgeScore },
                                { label: "Готовность помочь", value: selectedCall.helpfulnessScore },
                                { label: "Ясность ответов", value: selectedCall.clarityScore },
                                { label: "Общая оценка", value: selectedCall.overallScore, highlight: true },
                              ].map((s) => (
                                <div key={s.label} className="flex items-center justify-between">
                                  <span className="text-xs" style={{ color: s.highlight ? "var(--text-primary)" : "var(--text-secondary)" }}>{s.label}</span>
                                  <StarRating value={s.value} />
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Details */}
                          <div className="space-y-2">
                            <h4 className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-secondary)" }}>Детали</h4>
                            {selectedCall.greeting && <div className="text-xs p-2 rounded-lg" style={{ background: "rgba(5,2,6,0.5)", border: "1px solid rgba(147,51,234,0.1)" }}><span style={{ color: "var(--text-secondary)" }}>Приветствие:</span> <span style={{ color: "var(--text-primary)" }}>{selectedCall.greeting}</span></div>}
                            {selectedCall.objections && <div className="text-xs p-2 rounded-lg" style={{ background: "rgba(5,2,6,0.5)", border: "1px solid rgba(147,51,234,0.1)" }}><span style={{ color: "var(--text-secondary)" }}>Возражения:</span> <span style={{ color: "var(--text-primary)" }}>{selectedCall.objections}</span></div>}
                            {selectedCall.recommendations && <div className="text-xs p-2 rounded-lg" style={{ background: "rgba(5,2,6,0.5)", border: "1px solid rgba(147,51,234,0.1)" }}><span style={{ color: "var(--text-secondary)" }}>Рекомендации:</span> <span style={{ color: "var(--text-primary)" }}>{selectedCall.recommendations}</span></div>}
                            {selectedCall.followUp && <div className="text-xs p-2 rounded-lg" style={{ background: "rgba(5,2,6,0.5)", border: "1px solid rgba(147,51,234,0.1)" }}><span style={{ color: "var(--text-secondary)" }}>Перезвон:</span> <span style={{ color: "var(--text-primary)" }}>{selectedCall.followUp}</span></div>}
                          </div>

                          {/* Summary */}
                          {selectedCall.summary && (
                            <div className="md:col-span-2 p-3 rounded-xl" style={{ background: "rgba(217,70,239,0.05)", border: "1px solid rgba(217,70,239,0.15)" }}>
                              <h4 className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: "#D946EF" }}>Итоговый отчёт</h4>
                              <p className="text-xs leading-relaxed" style={{ color: "var(--text-primary)" }}>{selectedCall.summary}</p>
                            </div>
                          )}

                          {/* Transcript */}
                          {selectedCall.transcript && (
                            <div className="md:col-span-2">
                              <h4 className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: "var(--text-secondary)" }}>Транскрипция</h4>
                              <div className="text-xs font-mono-custom p-3 rounded-lg max-h-48 overflow-y-auto scrollbar-thin" style={{ background: "rgba(5,2,6,0.6)", border: "1px solid rgba(147,51,234,0.1)" }}>
                                {selectedCall.transcript.split("\n").map((line, i) => <p key={i} className="mb-1" style={{ color: "var(--text-primary)" }}>{line}</p>)}
                              </div>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        )}
      </motion.div>
    </div>
  );
}
