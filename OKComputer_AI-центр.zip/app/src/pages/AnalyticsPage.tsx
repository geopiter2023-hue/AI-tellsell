import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import { TrendingUp, Phone, Users, Target, Zap, Activity, PieChart } from "lucide-react";
import { StatBadge } from "@/components/StatBadge";

export function AnalyticsPage() {
  const { data: analytics, isLoading } = trpc.analytics.dashboard.useQuery();
  const { data: callsOverTime } = trpc.analytics.callsOverTime.useQuery({ days: 7 });
  const { data: topPerformers } = trpc.analytics.topPerformers.useQuery();

  if (isLoading || !analytics) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "var(--accent-neon)", borderTopColor: "transparent" }} />
      </div>
    );
  }

  const summary = analytics.summary;
  const peakHours = [...analytics.hourlyStats].filter((h) => h.calls > 0).sort((a, b) => b.calls - a.calls).slice(0, 12);
  const maxHourlyCalls = Math.max(...peakHours.map((h) => h.calls), 1);
  const emotions = analytics.emotionStats;
  const totalEmotions = Object.values(emotions).reduce((s, v) => s + v, 0) || 1;
  const outcomes = analytics.outcomeStats;
  const totalOutcomes = Object.values(outcomes).reduce((s, v) => s + v, 0) || 1;

  return (
    <div className="h-full flex flex-col gap-3 md:gap-4 overflow-y-auto scrollbar-thin">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="font-display text-xl md:text-3xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>Аналитика</h1>
      </motion.div>

      {/* Stats */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
        <StatBadge icon={<Phone size={14} />} label="Всего звонков" value={summary.totalCalls} color="#D946EF" />
        <StatBadge icon={<Zap size={14} />} label="Активные" value={summary.activeCalls} color="#22C55E" />
        <StatBadge icon={<Users size={14} />} label="Клиенты" value={summary.totalClients} color="#06B6D4" />
        <StatBadge icon={<Target size={14} />} label="Успешность" value={summary.overallSuccessRate} color="#FACC15" suffix="%" />
      </motion.div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 md:gap-4">
        {/* Call Volume */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="md:col-span-7 glass-panel p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={14} style={{ color: "var(--accent-neon)" }} />
            <h3 className="text-xs md:text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Звонки за неделю</h3>
          </div>
          <div className="flex items-end gap-1 md:gap-2 h-36 md:h-48">
            {callsOverTime?.map((day, i) => {
              const maxTotal = Math.max(...(callsOverTime?.map((d) => d.total) || [1]), 1);
              const height = (day.total / maxTotal) * 100;
              return (
                <div key={day.date} className="flex-1 flex flex-col items-center gap-1">
                  <div className="w-full flex gap-0.5 items-end" style={{ height: "100px" }}>
                    <motion.div className="flex-1 rounded-t-sm" style={{ background: "linear-gradient(to top, #D946EF, #9333EA)" }} initial={{ height: 0 }} animate={{ height: `${height}%` }} transition={{ duration: 0.8, delay: i * 0.1 }} />
                  </div>
                  <span className="text-[10px] md:text-xs" style={{ color: "var(--text-secondary)" }}>
                    {new Date(day.date).toLocaleDateString("ru-RU", { weekday: "short" })}
                  </span>
                  <span className="text-[10px] md:text-xs font-medium" style={{ color: "var(--text-primary)" }}>{day.total}</span>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Emotions */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="md:col-span-5 glass-panel p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <Activity size={14} style={{ color: "var(--accent-neon)" }} />
            <h3 className="text-xs md:text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Эмоции</h3>
          </div>
          <div className="space-y-2 md:space-y-3">
            {[
              { key: "joy", label: "Радость", color: "#FACC15" },
              { key: "calm", label: "Спокойствие", color: "#22C55E" },
              { key: "anger", label: "Напряжение", color: "#EF4444" },
              { key: "sad", label: "Тревога", color: "#3B82F6" },
              { key: "neutral", label: "Нейтрально", color: "#9CA3AF" },
            ].map(({ key, label, color }) => {
              const value = emotions[key as keyof typeof emotions] || 0;
              const pct = Math.round((value / totalEmotions) * 100);
              return (
                <div key={key}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs" style={{ color }}>{label}</span>
                    <span className="text-xs font-medium" style={{ color: "var(--text-primary)" }}>{value} ({pct}%)</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(147, 51, 234, 0.1)" }}>
                    <motion.div className="h-full rounded-full" style={{ background: color }} initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8 }} />
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Peak Hours */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="md:col-span-6 glass-panel p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <Activity size={14} style={{ color: "var(--accent-neon)" }} />
            <h3 className="text-xs md:text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Пиковые часы</h3>
          </div>
          <div className="grid grid-cols-4 sm:grid-cols-4 gap-2">
            {peakHours.map((h, i) => (
              <motion.div key={h.hour} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }} className="dark-well p-2 rounded-lg text-center">
                <div className="font-display text-base md:text-lg font-bold" style={{ color: "var(--accent-neon)" }}>{h.calls}</div>
                <div className="text-[10px] md:text-xs" style={{ color: "var(--text-secondary)" }}>{h.hour}:00</div>
                <div className="mt-1 h-1 rounded-full overflow-hidden" style={{ background: "rgba(147, 51, 234, 0.1)" }}>
                  <div className="h-full rounded-full" style={{ width: `${(h.calls / maxHourlyCalls) * 100}%`, background: "linear-gradient(90deg, #D946EF, #9333EA)" }} />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Outcomes */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="md:col-span-6 glass-panel p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <PieChart size={14} style={{ color: "var(--accent-neon)" }} />
            <h3 className="text-xs md:text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Результаты</h3>
          </div>
          <div className="grid grid-cols-2 gap-2 md:gap-3">
            {[
              { key: "success", label: "Успех", color: "#22C55E" },
              { key: "follow_up", label: "Повторный", color: "#D946EF" },
              { key: "no_answer", label: "Нет ответа", color: "#6B7280" },
              { key: "rejected", label: "Отказ", color: "#EF4444" },
              { key: "voicemail", label: "Гол. почта", color: "#3B82F6" },
              { key: "in_progress", label: "В процессе", color: "#F59E0B" },
            ].map(({ key, label, color }) => {
              const value = outcomes[key as keyof typeof outcomes] || 0;
              const pct = Math.round((value / totalOutcomes) * 100);
              return (
                <div key={key} className="flex items-center gap-2 md:gap-3 dark-well p-2 md:p-2.5 rounded-lg">
                  <div className="w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center font-display text-xs md:text-sm font-bold flex-shrink-0" style={{ background: `${color}15`, color }}>{value}</div>
                  <div className="min-w-0">
                    <div className="text-xs font-medium truncate" style={{ color: "var(--text-primary)" }}>{label}</div>
                    <div className="text-[10px] md:text-xs" style={{ color: "var(--text-secondary)" }}>{pct}%</div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>

        {/* Top Performers */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="md:col-span-12 glass-panel p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={14} style={{ color: "var(--accent-neon)" }} />
            <h3 className="text-xs md:text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Лучшие агенты</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 md:gap-3">
            {topPerformers?.map((agent, i) => (
              <motion.div key={agent.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 + i * 0.08 }} className="dark-well p-3 md:p-4 rounded-xl text-center">
                <div className="w-10 h-10 md:w-12 md:h-12 rounded-full mx-auto mb-2 flex items-center justify-center text-sm md:text-lg font-bold" style={{ background: "rgba(217, 70, 239, 0.15)", color: "#D946EF" }}>
                  {agent.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
                </div>
                <div className="text-xs md:text-sm font-medium truncate" style={{ color: "var(--text-primary)" }}>{agent.name}</div>
                <div className="text-[10px] md:text-xs mt-1" style={{ color: "var(--text-secondary)" }}>{agent.callsHandled} звонков</div>
                <div className="mt-1 md:mt-2 font-display text-base md:text-lg font-bold" style={{ color: "#22C55E" }}>{agent.successRate}%</div>
                <div className="text-[10px] md:text-xs" style={{ color: "var(--text-secondary)" }}>успех</div>
              </motion.div>
            )) || <div className="col-span-full text-center py-8" style={{ color: "var(--text-secondary)" }}>Нет данных</div>}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
