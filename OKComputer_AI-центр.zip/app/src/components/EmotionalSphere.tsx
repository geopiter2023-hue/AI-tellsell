import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";

function Sphere() {
  const meshRef = useRef<THREE.Mesh>(null);
  const pointsRef = useRef<THREE.Points>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (meshRef.current) {
      const pulse = Math.sin(t * 2) * 0.05 + 1;
      meshRef.current.scale.set(pulse, pulse, pulse);
      meshRef.current.rotation.y = t * 0.2;
      meshRef.current.rotation.x = Math.sin(t * 0.5) * 0.1;
    }
    if (pointsRef.current) {
      pointsRef.current.rotation.y = t * 0.15;
      pointsRef.current.rotation.x = Math.sin(t * 0.3) * 0.05;
    }
  });

  // Create particles geometry
  const particlesGeometry = useMemo(() => {
    const particleCount = 300;
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 1.8 + Math.random() * 0.8;
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return geo;
  }, []);

  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[5, 5, 5]} intensity={1.2} color="#D946EF" />
      <pointLight position={[-5, -5, -5]} intensity={0.6} color="#06B6D4" />
      <pointLight position={[0, 5, -5]} intensity={0.4} color="#9333EA" />

      {/* Main wireframe sphere */}
      <mesh ref={meshRef}>
        <icosahedronGeometry args={[1.5, 2]} />
        <meshStandardMaterial
          color="#0f0212"
          emissive="#D946EF"
          emissiveIntensity={0.3}
          wireframe
          transparent
          opacity={0.7}
        />
      </mesh>

      {/* Inner solid sphere */}
      <mesh>
        <icosahedronGeometry args={[1.2, 1]} />
        <meshStandardMaterial
          color="#0f0212"
          emissive="#9333EA"
          emissiveIntensity={0.15}
          transparent
          opacity={0.3}
        />
      </mesh>

      {/* Orbiting particles */}
      <points ref={pointsRef} geometry={particlesGeometry}>
        <pointsMaterial
          size={0.03}
          color="#D946EF"
          transparent
          opacity={0.8}
          sizeAttenuation
        />
      </points>

      <OrbitControls
        enableZoom={false}
        autoRotate
        autoRotateSpeed={0.5}
        enablePan={false}
        maxPolarAngle={Math.PI * 0.8}
        minPolarAngle={Math.PI * 0.2}
      />
    </>
  );
}

export function EmotionalSphere() {
  return (
    <div className="w-full h-full" style={{ minHeight: "300px" }}>
      <Canvas
        camera={{ position: [0, 0, 5], fov: 50 }}
        style={{ background: "transparent" }}
        gl={{ antialias: true, alpha: true }}
      >
        <Sphere />
      </Canvas>
    </div>
  );
}
