import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import { useState, useEffect, useRef } from "react";
import { Bot, User, Activity } from "lucide-react";

const emotionColors: Record<string, string> = {
  joy: "#FACC15",
  calm: "#22C55E",
  anger: "#EF4444",
  sad: "#3B82F6",
  neutral: "#9CA3AF",
};

export function TranscriptPanel() {
  // Get transcript for the first active call
  const { data: activeCalls } = trpc.calls.active.useQuery();
  const firstActiveCall = activeCalls?.find((c) => c.status === "in_progress");
  const { data: transcriptEntries } = trpc.calls.transcript.useQuery(
    { callId: firstActiveCall?.id ?? 0 },
    { enabled: !!firstActiveCall, refetchInterval: 2000 }
  );

  const scrollRef = useRef<HTMLDivElement>(null);
  const [displayedLines, setDisplayedLines] = useState<typeof transcriptEntries>([]);

  // Typewriter effect: show entries one by one
  useEffect(() => {
    if (!transcriptEntries) return;
    if (transcriptEntries.length === 0) {
      setDisplayedLines([]);
      return;
    }

    // Show entries progressively
    const targetLength = transcriptEntries.length;
    const currentLength = displayedLines?.length ?? 0;

    if (currentLength < targetLength) {
      const timer = setTimeout(() => {
        setDisplayedLines(transcriptEntries.slice(0, currentLength + 1));
      }, 300);
      return () => clearTimeout(timer);
    } else if (currentLength > targetLength) {
      setDisplayedLines(transcriptEntries);
    }
  }, [transcriptEntries]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [displayedLines]);

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 border-b" style={{ borderColor: "var(--border-glass)" }}>
        <div className="flex items-center gap-2">
          <Activity size={14} style={{ color: "var(--accent-neon)" }} />
          <span className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>
            Транскрипция
          </span>
        </div>
        {firstActiveCall && (
          <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
            {firstActiveCall.clientName || firstActiveCall.phone}
          </span>
        )}
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-thin px-4 py-3">
        {!firstActiveCall ? (
          <div className="flex items-center justify-center h-full">
            <span className="text-sm" style={{ color: "var(--text-secondary)" }}>
              Ожидание активного звонка...
            </span>
          </div>
        ) : !displayedLines || displayedLines.length === 0 ? (
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "var(--accent-neon)" }} />
            <span className="text-sm font-mono-custom typing-cursor" style={{ color: "var(--text-secondary)" }}>
              Прослушивание...
            </span>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {displayedLines.map((entry) => {
              const isAi = entry.speaker === "ai";
              const emotionColor = entry.emotion ? emotionColors[entry.emotion] || "#9CA3AF" : "#9CA3AF";

              return (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex items-start gap-2"
                >
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{
                      background: isAi ? "rgba(217, 70, 239, 0.2)" : "rgba(6, 182, 212, 0.2)",
                    }}
                  >
                    {isAi ? (
                      <Bot size={10} style={{ color: "#D946EF" }} />
                    ) : (
                      <User size={10} style={{ color: "#06B6D4" }} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span
                        className="text-xs font-medium"
                        style={{ color: isAi ? "#D946EF" : "#06B6D4" }}
                      >
                        {isAi ? "ИИ-агент" : "Клиент"}
                      </span>
                      {entry.emotion && (
                        <span
                          className="text-xs px-1.5 py-0.5 rounded-full"
                          style={{ background: `${emotionColor}15`, color: emotionColor, fontSize: "10px" }}
                        >
                          {entry.emotion}
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-mono-custom leading-relaxed mt-0.5" style={{ color: "var(--text-primary)" }}>
                      {entry.text}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
