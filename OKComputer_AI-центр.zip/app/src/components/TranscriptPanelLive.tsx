import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Bot, User, Activity } from "lucide-react";

interface TranscriptLine {
  callId: number;
  speaker: "ai" | "client";
  text: string;
  emotion: string;
  elapsedSeconds: number;
}

interface LiveCall {
  id: number;
  clientName: string | null;
  phone: string;
  status: string;
}

const emotionColors: Record<string, string> = {
  joy: "#FACC15",
  calm: "#22C55E",
  anger: "#EF4444",
  sad: "#3B82F6",
  neutral: "#9CA3AF",
  interest: "#D946EF",
};

const emotionLabelsRu: Record<string, string> = {
  joy: "Радость",
  calm: "Спокойствие",
  anger: "Напряжение",
  sad: "Тревога",
  neutral: "Нейтрально",
  interest: "Интерес",
};

export function TranscriptPanelLive({
  latestLine,
  activeCall,
}: {
  latestLine: TranscriptLine | null;
  activeCall: LiveCall | undefined;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [lines, setLines] = useState<Array<{ id: number; speaker: "ai" | "client"; text: string; emotion: string }>>([]);

  // Add new transcript line when it arrives
  useEffect(() => {
    if (latestLine) {
      setLines((prev) => [
        ...prev,
        {
          id: Date.now(),
          speaker: latestLine.speaker,
          text: latestLine.text,
          emotion: latestLine.emotion,
        },
      ]);
    }
  }, [latestLine]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines]);

  // Clear lines when no active call
  useEffect(() => {
    if (!activeCall) {
      setLines([]);
    }
  }, [activeCall]);

  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 border-b" style={{ borderColor: "var(--border-glass)" }}>
        <div className="flex items-center gap-2">
          <Activity size={14} style={{ color: "var(--accent-neon)" }} />
          <span className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>
            Транскрипция
          </span>
          {latestLine && (
            <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: "rgba(217,70,239,0.15)", color: "#D946EF", fontSize: "10px" }}>
              LIVE
            </span>
          )}
        </div>
        {activeCall && (
          <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
            {activeCall.clientName || activeCall.phone}
          </span>
        )}
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-thin px-4 py-3">
        {!activeCall ? (
          <div className="flex items-center justify-center h-full">
            <span className="text-sm" style={{ color: "var(--text-secondary)" }}>
              Ожидание активного звонка...
            </span>
          </div>
        ) : lines.length === 0 ? (
          <div className="flex flex-col items-center gap-3 h-full justify-center">
            <div className="w-3 h-3 rounded-full animate-ping" style={{ background: "var(--accent-neon)" }} />
            <span className="text-sm font-mono-custom" style={{ color: "var(--text-secondary)" }}>
              Звонок соединяется...
            </span>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {lines.map((entry) => {
              const isAi = entry.speaker === "ai";
              const emotionColor = entry.emotion ? emotionColors[entry.emotion] || "#9CA3AF" : "#9CA3AF";
              const emotionLabel = entry.emotion ? emotionLabelsRu[entry.emotion] || entry.emotion : "";

              return (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 5, x: isAi ? -5 : 5 }}
                  animate={{ opacity: 1, y: 0, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex items-start gap-2"
                >
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{
                      background: isAi ? "rgba(217, 70, 239, 0.2)" : "rgba(6, 182, 212, 0.2)",
                    }}
                  >
                    {isAi ? (
                      <Bot size={12} style={{ color: "#D946EF" }} />
                    ) : (
                      <User size={12} style={{ color: "#06B6D4" }} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span
                        className="text-xs font-medium"
                        style={{ color: isAi ? "#D946EF" : "#06B6D4" }}
                      >
                        {isAi ? "ИИ-агент" : "Клиент"}
                      </span>
                      {entry.emotion && (
                        <span
                          className="text-xs px-1.5 py-0.5 rounded-full"
                          style={{ background: `${emotionColor}15`, color: emotionColor, fontSize: "10px" }}
                        >
                          {emotionLabel}
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-mono-custom leading-relaxed mt-0.5" style={{ color: "var(--text-primary)" }}>
                      {entry.text}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
