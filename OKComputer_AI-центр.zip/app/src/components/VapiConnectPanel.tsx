import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { motion, AnimatePresence } from "framer-motion";
import { Key, Phone, RefreshCw, ExternalLink, AlertCircle, CheckCircle, ChevronDown, ChevronUp } from "lucide-react";

export function VapiConnectPanel() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [callForm, setCallForm] = useState({
    customerNumber: "",
    customerName: "",
    assistantId: "",
    phoneNumberId: "",
  });

  const { data: status } = trpc.vapi.status.useQuery();
  const { data: assistants } = trpc.vapi.listAssistants.useQuery(undefined, {
    enabled: status?.configured === true,
  });
  const { data: phoneNumbers } = trpc.vapi.listPhoneNumbers.useQuery(undefined, {
    enabled: status?.configured === true,
  });

  const utils = trpc.useUtils();

  const makeCallMutation = trpc.vapi.makeCall.useMutation({
    onSuccess: () => {
      utils.calls.active.invalidate();
      setCallForm({ customerNumber: "", customerName: "", assistantId: callForm.assistantId, phoneNumberId: callForm.phoneNumberId });
    },
  });

  const isConfigured = status?.configured === true;

  const handleMakeCall = () => {
    if (!callForm.customerNumber || !callForm.assistantId || !callForm.phoneNumberId) return;
    makeCallMutation.mutate({
      assistantId: callForm.assistantId,
      phoneNumberId: callForm.phoneNumberId,
      customerNumber: callForm.customerNumber,
      customerName: callForm.customerName || undefined,
    });
  };

  return (
    <div className="glass-panel overflow-hidden">
      <div
        className="flex items-center justify-between px-3 md:px-4 py-2.5 md:py-3 cursor-pointer transition-colors hover:bg-[rgba(217,70,239,0.05)]"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2 md:gap-3 min-w-0 flex-1">
          <div
            className="w-7 h-7 md:w-8 md:h-8 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{
              background: isConfigured ? "rgba(34, 197, 94, 0.15)" : "rgba(245, 158, 11, 0.15)",
              color: isConfigured ? "#22C55E" : "#F59E0B",
            }}
          >
            {isConfigured ? <CheckCircle size={14} /> : <Key size={14} />}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="text-xs md:text-sm font-semibold truncate" style={{ color: "var(--text-primary)" }}>
                Vapi.ai интеграция
              </h3>
              <span
                className="text-[10px] md:text-xs px-1.5 md:px-2 py-0.5 rounded-full font-medium flex-shrink-0"
                style={{
                  background: isConfigured ? "rgba(34, 197, 94, 0.15)" : "rgba(245, 158, 11, 0.15)",
                  color: isConfigured ? "#22C55E" : "#F59E0B",
                }}
              >
                {isConfigured ? "OK" : "Настроить"}
              </span>
            </div>
            <p className="text-[10px] md:text-xs truncate" style={{ color: "var(--text-secondary)" }}>
              {isConfigured
                ? `${(assistants as Array<Record<string, unknown>>)?.length || 0} ассистентов`
                : "Добавьте API ключ"}
            </p>
          </div>
        </div>
        {isExpanded ? <ChevronUp size={14} style={{ color: "var(--text-secondary)" }} /> : <ChevronDown size={14} style={{ color: "var(--text-secondary)" }} />}
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-3 md:px-4 pb-3 md:pb-4 border-t" style={{ borderColor: "var(--border-glass)" }}>
              {!isConfigured && (
                <div className="mt-3 space-y-3">
                  <div className="flex items-start gap-2 md:gap-3 p-2.5 md:p-3 rounded-xl" style={{ background: "rgba(245, 158, 11, 0.1)", border: "1px solid rgba(245, 158, 11, 0.2)" }}>
                    <AlertCircle size={14} className="text-yellow-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs md:text-sm font-medium text-yellow-400">API ключ не настроен</p>
                      <p className="text-[10px] md:text-xs mt-1" style={{ color: "var(--text-secondary)" }}>
                        Добавьте VAPI_API_KEY в переменные окружения сервера
                      </p>
                    </div>
                  </div>

                  <button onClick={() => setShowSetup(!showSetup)} className="flex items-center gap-1.5 text-xs font-medium" style={{ color: "#D946EF" }}>
                    <ExternalLink size={12} />
                    {showSetup ? "Скрыть" : "Как настроить?"}
                  </button>

                  <AnimatePresence>
                    {showSetup && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="space-y-1.5 overflow-hidden">
                        {[
                          { step: "1", text: "Зарегистрируйтесь на vapi.ai" },
                          { step: "2", text: "Купите номер телефона" },
                          { step: "3", text: "Создайте ИИ-ассистента" },
                          { step: "4", text: "Добавьте VAPI_API_KEY в .env" },
                          { step: "5", text: "Перезапустите сервер" },
                        ].map(({ step, text }) => (
                          <div key={step} className="flex items-center gap-2 p-1.5 rounded-lg" style={{ background: "rgba(147, 51, 234, 0.05)" }}>
                            <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0" style={{ background: "rgba(217, 70, 239, 0.2)", color: "#D946EF" }}>{step}</span>
                            <span className="text-[11px] md:text-xs" style={{ color: "var(--text-primary)" }}>{text}</span>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {isConfigured && (
                <div className="mt-3 space-y-2.5">
                  <div>
                    <label className="text-[10px] md:text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>ИИ-ассистент</label>
                    <select value={callForm.assistantId} onChange={(e) => setCallForm({ ...callForm, assistantId: e.target.value })} className="w-full px-2.5 md:px-3 py-1.5 md:py-2 rounded-lg text-xs md:text-sm outline-none" style={{ background: "rgba(5, 2, 6, 0.60)", border: "1px solid rgba(147, 51, 234, 0.2)", color: "var(--text-primary)" }}>
                      <option value="">Выберите</option>
                      {(assistants as Array<{ id?: string; name?: string }> || []).map((a) => (
                        <option key={a.id} value={a.id}>{a.name || a.id}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] md:text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Номер</label>
                    <select value={callForm.phoneNumberId} onChange={(e) => setCallForm({ ...callForm, phoneNumberId: e.target.value })} className="w-full px-2.5 md:px-3 py-1.5 md:py-2 rounded-lg text-xs md:text-sm outline-none" style={{ background: "rgba(5, 2, 6, 0.60)", border: "1px solid rgba(147, 51, 234, 0.2)", color: "var(--text-primary)" }}>
                      <option value="">Выберите</option>
                      {(phoneNumbers as Array<{ id?: string; number?: string }> || []).map((p) => (
                        <option key={p.id} value={p.id}>{p.number || p.id}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] md:text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Клиент *</label>
                      <input type="tel" placeholder="+1 555..." value={callForm.customerNumber} onChange={(e) => setCallForm({ ...callForm, customerNumber: e.target.value })} className="w-full px-2.5 md:px-3 py-1.5 md:py-2 rounded-lg text-xs md:text-sm outline-none placeholder:text-[#A855F7]/40" style={{ background: "rgba(5, 2, 6, 0.60)", border: "1px solid rgba(147, 51, 234, 0.2)", color: "var(--text-primary)" }} />
                    </div>
                    <div>
                      <label className="text-[10px] md:text-xs font-medium mb-1 block" style={{ color: "var(--text-secondary)" }}>Имя</label>
                      <input type="text" placeholder="Иван..." value={callForm.customerName} onChange={(e) => setCallForm({ ...callForm, customerName: e.target.value })} className="w-full px-2.5 md:px-3 py-1.5 md:py-2 rounded-lg text-xs md:text-sm outline-none placeholder:text-[#A855F7]/40" style={{ background: "rgba(5, 2, 6, 0.60)", border: "1px solid rgba(147, 51, 234, 0.2)", color: "var(--text-primary)" }} />
                    </div>
                  </div>

                  <button onClick={handleMakeCall} disabled={!callForm.customerNumber || !callForm.assistantId || !callForm.phoneNumberId || makeCallMutation.isPending} className="w-full flex items-center justify-center gap-2 px-3 md:px-4 py-2 rounded-xl text-xs md:text-sm font-medium disabled:opacity-40" style={{ background: "rgba(217, 70, 239, 0.2)", border: "1px solid rgba(217, 70, 239, 0.4)", color: "#D946EF" }}>
                    {makeCallMutation.isPending ? <RefreshCw size={12} className="animate-spin" /> : <Phone size={12} />}
                    {makeCallMutation.isPending ? "Звоним..." : "Позвонить"}
                  </button>
                </div>
              )}

              <div className="mt-2 pt-2 border-t" style={{ borderColor: "var(--border-glass)" }}>
                <a href="https://vapi.ai" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[10px] md:text-xs" style={{ color: "var(--text-secondary)" }}>
                  <ExternalLink size={10} /> vapi.ai
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
