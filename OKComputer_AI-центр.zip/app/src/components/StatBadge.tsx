import { motion } from "framer-motion";
import { type ReactNode } from "react";

interface StatBadgeProps {
  icon: ReactNode;
  label: string;
  value: number;
  color: string;
  suffix?: string;
}

export function StatBadge({ icon, label, value, color, suffix }: StatBadgeProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="stat-badge flex items-center gap-2 md:gap-3 p-2 md:p-3"
      style={{ animation: "pulse-glow 3s ease-in-out infinite" }}
    >
      <div
        className="w-6 h-6 md:w-8 md:h-8 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}15`, color }}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <div className="font-display text-base md:text-xl font-bold" style={{ color: "var(--text-primary)" }}>
          {value}{suffix || ""}
        </div>
        <div className="text-[10px] md:text-xs truncate" style={{ color: "var(--text-secondary)" }}>
          {label}
        </div>
      </div>
    </motion.div>
  );
}
