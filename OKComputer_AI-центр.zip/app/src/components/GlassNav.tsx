import { useLocation, useNavigate } from "react-router";
import { Phone, Users, BarChart3, Radio, Eye } from "lucide-react";

const navItems = [
  { path: "/", label: "Звонки", icon: Radio },
  { path: "/campaigns", label: "Кампании", icon: Phone },
  { path: "/clients", label: "Клиенты", icon: Users },
  { path: "/secret-shopper", label: "Тайный покупатель", icon: Eye },
  { path: "/analytics", label: "Аналитика", icon: BarChart3 },
];

export function GlassNav() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="fixed bottom-3 md:bottom-6 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-24px)] md:w-auto max-w-full">
      <div
        className="flex items-center justify-center gap-0.5 md:gap-1 px-1.5 md:px-2 py-1.5 md:py-2 rounded-2xl overflow-x-auto"
        style={{
          background: "rgba(15, 2, 18, 0.85)",
          backdropFilter: "blur(32px) saturate(160%)",
          WebkitBackdropFilter: "blur(32px) saturate(160%)",
          border: "1px solid rgba(147, 51, 234, 0.25)",
          boxShadow: "0 8px 40px rgba(0,0,0,0.5), inset 0 1px 1px rgba(255,255,255,0.05)",
        }}
      >
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="relative flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-2 md:py-2.5 rounded-xl transition-all duration-300 flex-shrink-0"
              style={{
                background: isActive ? "rgba(217, 70, 239, 0.15)" : "transparent",
                border: isActive ? "1px solid rgba(217, 70, 239, 0.3)" : "1px solid transparent",
              }}
            >
              <Icon
                size={18}
                style={{
                  color: isActive ? "#D946EF" : "#A855F7",
                  filter: isActive ? "drop-shadow(0 0 6px rgba(217, 70, 239, 0.5))" : "none",
                }}
              />
              <span
                className="text-xs md:text-sm font-medium transition-all duration-300 hidden sm:inline"
                style={{
                  color: isActive ? "#F3E8FF" : "#A855F7",
                }}
              >
                {item.label}
              </span>
              {isActive && (
                <div
                  className="absolute inset-0 rounded-xl"
                  style={{
                    boxShadow: "0 0 20px rgba(217, 70, 239, 0.15)",
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
