import { Outlet } from "react-router";
import { GlassNav } from "./GlassNav";

export function AppLayout() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Background gradient */}
      <div
        className="fixed inset-0 z-0"
        style={{
          background: `
            radial-gradient(ellipse at 20% 50%, rgba(147, 51, 234, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 30%, rgba(217, 70, 239, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse at 50% 80%, rgba(6, 182, 212, 0.08) 0%, transparent 50%),
            linear-gradient(180deg, #050206 0%, #0a0512 50%, #050206 100%)
          `,
        }}
      />
      <div className="video-bg-overlay" />

      {/* Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top Bar */}
        <header className="flex items-center justify-between px-3 md:px-6 py-3 md:py-4">
          <div className="flex items-center gap-2 md:gap-3">
            <div className="w-7 h-7 md:w-8 md:h-8 rounded-lg bg-gradient-to-br from-[#D946EF] to-[#9333EA] flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
              </svg>
            </div>
            <span className="font-display text-base md:text-xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>
              AI Колл-центр
            </span>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: "rgba(34, 197, 94, 0.15)", border: "1px solid rgba(34, 197, 94, 0.3)" }}>
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-medium text-green-400">Система онлайн</span>
            </div>
            {/* Mobile-only compact indicator */}
            <div className="md:hidden flex items-center gap-1.5 px-2 py-1 rounded-full" style={{ background: "rgba(34, 197, 94, 0.1)", border: "1px solid rgba(34, 197, 94, 0.2)" }}>
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 px-3 md:px-6 pb-20 md:pb-24 pt-1 md:pt-2">
          <Outlet />
        </main>

        {/* Bottom Navigation */}
        <GlassNav />
      </div>
    </div>
  );
}
