import { trpc } from "@/providers/trpc";
import { motion } from "framer-motion";
import { Phone, PhoneIncoming, PhoneOutgoing, Clock, Activity } from "lucide-react";

const statusConfig: Record<string, { color: string; bg: string; label: string }> = {
  in_progress: { color: "#22C55E", bg: "rgba(34, 197, 94, 0.15)", label: "В эфире" },
  ringing: { color: "#F59E0B", bg: "rgba(245, 158, 11, 0.15)", label: "Звонок" },
  queued: { color: "#6B7280", bg: "rgba(107, 114, 128, 0.15)", label: "В очереди" },
  completed: { color: "#3B82F6", bg: "rgba(59, 130, 246, 0.15)", label: "Завершён" },
  failed: { color: "#EF4444", bg: "rgba(239, 68, 68, 0.15)", label: "Ошибка" },
  missed: { color: "#EF4444", bg: "rgba(239, 68, 68, 0.15)", label: "Пропущен" },
};

const emotionConfig: Record<string, { color: string; label: string }> = {
  joy: { color: "#FACC15", label: "Радость" },
  calm: { color: "#22C55E", label: "Спокойствие" },
  anger: { color: "#EF4444", label: "Напряжение" },
  sad: { color: "#3B82F6", label: "Тревога" },
  neutral: { color: "#9CA3AF", label: "Нейтрально" },
};

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}

export function CallList() {
  const { data: calls, isLoading } = trpc.calls.active.useQuery();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="w-6 h-6 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "var(--accent-neon)", borderTopColor: "transparent" }} />
      </div>
    );
  }

  if (!calls || calls.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-32 text-center">
        <Phone size={24} style={{ color: "var(--text-secondary)" }} />
        <p className="text-sm mt-2" style={{ color: "var(--text-secondary)" }}>Нет активных звонков</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      {calls.map((call, index) => {
        const status = statusConfig[call.status] || statusConfig.queued;
        const emotion = call.emotionLabel ? emotionConfig[call.emotionLabel] : null;
        const DirectionIcon = call.direction === "inbound" ? PhoneIncoming : PhoneOutgoing;

        return (
          <motion.div
            key={call.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="glass-panel-hover p-3 cursor-pointer transition-all duration-300"
            style={{
              background: call.status === "in_progress" ? "rgba(217, 70, 239, 0.05)" : "rgba(15, 2, 18, 0.4)",
              borderRadius: "12px",
              border: `1px solid ${call.status === "in_progress" ? "rgba(217, 70, 239, 0.25)" : "rgba(147, 51, 234, 0.1)"}`,
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ background: `${status.color}15`, color: status.color }}
                >
                  <DirectionIcon size={14} />
                </div>
                <div>
                  <div className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>
                    {call.clientName || call.phone}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span
                      className="text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{ background: status.bg, color: status.color }}
                    >
                      {status.label}
                    </span>
                    {call.duration > 0 && (
                      <span className="flex items-center gap-1 text-xs" style={{ color: "var(--text-secondary)" }}>
                        <Clock size={10} />
                        {formatDuration(call.duration)}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {emotion && (
                  <div
                    className="flex items-center gap-1 px-2 py-0.5 rounded-full"
                    style={{ background: `${emotion.color}15` }}
                  >
                    <Activity size={10} style={{ color: emotion.color }} />
                    <span className="text-xs font-medium" style={{ color: emotion.color }}>
                      {emotion.label}
                    </span>
                  </div>
                )}
                {call.status === "in_progress" && (
                  <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "#22C55E" }} />
                )}
              </div>
            </div>

            {/* Progress bar for active calls */}
            {call.status === "in_progress" && (
              <div className="mt-2 h-0.5 rounded-full overflow-hidden" style={{ background: "rgba(147, 51, 234, 0.1)" }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: "linear-gradient(90deg, #D946EF, #9333EA)" }}
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: call.duration || 60, ease: "linear" }}
                />
              </div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}
