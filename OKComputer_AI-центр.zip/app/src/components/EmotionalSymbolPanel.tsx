import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const SYMBOLS = [
  { id: "joy", char: "\u2726", color: "#FACC15", label: "Радость" },
  { id: "calm", char: "\u25CB", color: "#22C55E", label: "Спокойствие" },
  { id: "anger", char: "\u25B2", color: "#EF4444", label: "Напряжение" },
  { id: "sad", char: "\u25BD", color: "#3B82F6", label: "Тревога" },
  { id: "interest", char: "\u25C7", color: "#D946EF", label: "Интерес" },
];

export function EmotionalSymbolPanel() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [history, setHistory] = useState<{ id: string; char: string; color: string; label: string }[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const next = Math.floor(Math.random() * SYMBOLS.length);
      setActiveIndex(next);
      setHistory((h) => [...h.slice(-4), SYMBOLS[next]]);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative h-full w-full flex flex-col items-center justify-center p-4">
      {/* Active symbol */}
      <div className="relative w-24 h-24 flex items-center justify-center mb-4">
        <AnimatePresence mode="wait">
          <motion.span
            key={SYMBOLS[activeIndex].id}
            initial={{ opacity: 0, scale: 0.3, rotate: -30 }}
            animate={{
              opacity: 1,
              scale: 1.3,
              rotate: 0,
            }}
            exit={{ opacity: 0, scale: 0.5, rotate: 30 }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="absolute text-5xl font-bold"
            style={{
              color: SYMBOLS[activeIndex].color,
              textShadow: `0 0 25px ${SYMBOLS[activeIndex].color}80, 0 0 50px ${SYMBOLS[activeIndex].color}40`,
            }}
          >
            {SYMBOLS[activeIndex].char}
          </motion.span>
        </AnimatePresence>
        {/* Glow ring */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            border: `2px solid ${SYMBOLS[activeIndex].color}30`,
            boxShadow: `0 0 20px ${SYMBOLS[activeIndex].color}20`,
          }}
          animate={{
            scale: [1, 1.15, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>

      {/* Label */}
      <AnimatePresence mode="wait">
        <motion.span
          key={SYMBOLS[activeIndex].id + "-label"}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -5 }}
          className="text-xs font-medium tracking-wider uppercase"
          style={{ color: SYMBOLS[activeIndex].color }}
        >
          {SYMBOLS[activeIndex].label}
        </motion.span>
      </AnimatePresence>

      {/* History dots */}
      <div className="flex items-center gap-2 mt-4">
        {history.map((s, i) => (
          <motion.div
            key={`${s.id}-${i}`}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-2 h-2 rounded-full"
            style={{ backgroundColor: s.color }}
          />
        ))}
      </div>
    </div>
  );
}
